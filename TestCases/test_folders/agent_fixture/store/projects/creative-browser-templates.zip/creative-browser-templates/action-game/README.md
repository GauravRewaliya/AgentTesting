# Lantern Keep — tiny 2D action game

A small side-on action game that runs in the browser. One hand-built room, one enemy type, and a fighter who can run, jump, dash and swing a sword. The point of it is *feel*: hit-stop, screen shake, sparks and lantern light make every hit land.

Plain JavaScript and Canvas 2D. No libraries, no build step, no image files: every sprite and tile is drawn in code.

## Run it

Open `index.html` in a browser. That's it.

If your browser blocks local files, serve the folder instead:

```bash
python3 -m http.server 8000
```

Then open http://localhost:8000.

## Controls

| Action | Keys |
|---|---|
| Move | A / D or ← / → |
| Jump | Space, W or ↑ |
| Dash | Shift or K |
| Attack (3-hit combo) | J, X or mouse click |
| Restart | R |
| Toggle hit-stop / shake / particles / lighting | 1 / 2 / 3 / 4 |
| Toggle all effects | G |

Press 1–4 mid-fight to feel what each effect adds.

## URL options

| Option | What it does |
|---|---|
| `?juice=0` | Start with every effect off |
| `?hud=0` | Hide the help text along the bottom |
| `?manual=1` | Step mode: the game only advances when you call `GAME.step(keys)` from code |

## What's inside

- `index.html`: the page.
- `game.js`: the whole game.

The game runs at a fixed 60 updates per second on a 320×180 pixel canvas, scaled up to fit the window with hard pixel edges.

A `window.GAME` object lets you drive or read the game from code: `GAME.step({ right: true, attack: true })`, `GAME.state()`, `GAME.setJuice(false)`.

## Make it yours

- **The room** is the `ROOM_SRC` text map near the top of `game.js`. `#` is stone, `P` is the player start, `E` is an enemy and `L` is a hanging lantern. A `|` pins everything after it to the right wall.
- **Colours and sprites** are in `drawPlayerSprite` and `drawHuskSprite`. Each sprite is a list of small rectangles.
- **Feel**: the hit-stop length, shake strength, dash speed and jump height are plain numbers in `updatePlayer`, `hitEnemy` and `hurtPlayer`.

## Notes

- Tested in desktop Chrome. Other modern browsers should work but haven't been checked.
- Keyboard and mouse only: no gamepad or touch controls yet.
- There is no sound.

## License

Free to use, change and share for any purpose, personal or commercial. No credit needed.
