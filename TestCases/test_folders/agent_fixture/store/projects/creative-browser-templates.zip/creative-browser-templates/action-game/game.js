// Lantern Keep: a tiny original 2D action demo. Plain browser Canvas 2D, no libraries.
// All art is drawn in code (synthetic pixel art). Fixed 60 Hz simulation at 320x180, scaled up.
(() => {
'use strict';
const W = 320, H = 180, T = 8;
const params = new URLSearchParams(location.search);
const MANUAL = params.has('manual');          // step mode: frames advance only through GAME.step() (automated tests, frame-by-frame rendering)
const SHOW_HELP = params.get('hud') !== '0';

// ---------- seeded random (so restarts and test runs are repeatable) ----------
let seed = 1337;
function rnd() { seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
const rr = (a, b) => a + rnd() * (b - a);
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, u) => a + (b - a) * u;
const easeOut = u => 1 - Math.pow(1 - clamp(u, 0, 1), 3);

// ---------- the room (hand-authored). "left|right" pins the right part to the right wall ----------
// # stone   P player   E enemy   L hanging lantern
const ROOM_SRC = [
  '',
  '',
  '........L.....................L...............L',
  '',
  '',
  '',
  '|#########......',
  '',
  '',
  '...............######',
  '',
  '................................E',
  '#######......................#######',
  '#######|####',
  '#######|####',
  '#######.................####|####',
  '#######|#####',
  '#######.....###|#####',
  '#######|#########',
  '#######|#########',
  '#######..P..............E.............E|#########',
  '######################################################',
  '######################################################',
  '######################################################',
];
const IW = 54, COLS = IW + 2, ROWS = ROOM_SRC.length + 2, WW = COLS * T, WH = ROWS * T;
const grid = [], spawns = { enemies: [], lanterns: [], player: null };
(function parseRoom() {
  grid.push('#'.repeat(COLS).split(''));
  ROOM_SRC.forEach((src, r) => {
    let row;
    if (src.includes('|')) { const [a, b] = src.split('|'); row = a.padEnd(IW - b.length, '.') + b; }
    else row = src.padEnd(IW, '.');
    row = ('#' + row.slice(0, IW) + '#').split('');
    row.forEach((ch, c) => {
      if (ch === 'P') spawns.player = { c, r: r + 1 };
      if (ch === 'E') spawns.enemies.push({ c, r: r + 1 });
      if (ch === 'L') spawns.lanterns.push({ x: c * T + 4, y: (r + 1) * T + 4 });
      if (ch !== '#') row[c] = '.';
    });
    grid.push(row);
  });
  grid.push('#'.repeat(COLS).split(''));
})();
const solidT = (c, r) => c < 0 || r < 0 || c >= COLS || r >= ROWS || grid[r][c] === '#';
const solidAt = (x, y) => solidT(Math.floor(x / T), Math.floor(y / T));
function boxHits(e) {
  const c0 = Math.floor(e.x / T), c1 = Math.floor((e.x + e.w - 0.001) / T), r0 = Math.floor(e.y / T), r1 = Math.floor((e.y + e.h - 0.001) / T);
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) if (solidT(c, r)) return true;
  return false;
}
function moveX(e, dx) {
  e.x += dx; if (!boxHits(e)) return false;
  e.x = dx > 0 ? Math.floor((e.x + e.w - 0.001) / T) * T - e.w : (Math.floor(e.x / T) + 1) * T;
  return true;
}
function moveY(e, dy) {
  e.y += dy; if (!boxHits(e)) return false;
  e.y = dy > 0 ? Math.floor((e.y + e.h - 0.001) / T) * T - e.h : (Math.floor(e.y / T) + 1) * T;
  return true;
}
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

// ---------- canvases ----------
const screen = document.getElementById('game'), sctx = screen.getContext('2d');
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; return [c, x]; };
const [buf, b] = mk(W, H), [lightCv, l] = mk(W, H), [spr, sp] = mk(32, 32), [tintCv, tn] = mk(32, 32);
let S = 4;
function resize() {
  S = Math.max(1, Math.floor(Math.min(innerWidth / W, innerHeight / H)));
  screen.width = W * S; screen.height = H * S;
  screen.style.width = W * S + 'px'; screen.style.height = H * S + 'px';
}
addEventListener('resize', resize); resize();

function px(c, x, y, w, h, col) { c.fillStyle = col; c.fillRect(x, y, w, h); }
function line(c, x0, y0, x1, y1, col) {
  c.fillStyle = col; const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) | 0;
  for (let i = 0; i <= n; i++) { const u = n ? i / n : 0; c.fillRect(Math.round(x0 + (x1 - x0) * u), Math.round(y0 + (y1 - y0) * u), 1, 1); }
}

// ---------- pre-rendered room art ----------
const [tilesCv, tc] = mk(WW, WH);
const BGW = W + Math.ceil((WW - W) * 0.5) + 2, BGH = H + Math.ceil((WH - H) * 0.5) + 2;
const [bgCv, bg] = mk(BGW, BGH);
(function paintRoom() {
  let s = 99; const r = () => { s = (s * 1664525 + 1013904223) | 0; return ((s >>> 8) & 0xffff) / 65536; };
  // far wall
  px(bg, 0, 0, BGW, BGH, '#11141f');
  for (let y = 0; y < BGH; y += 8) for (let x = ((y / 8) % 2) * 8 - 8; x < BGW; x += 16) {
    px(bg, x, y, 16, 1, '#0c0e17'); px(bg, x, y, 1, 8, '#0c0e17');
    if (r() < 0.12) px(bg, x + 2, y + 2, 12, 5, '#151927');
    if (r() < 0.06) px(bg, x + 3, y + 3, 3, 1, '#1b2030');
  }
  for (let x = 40; x < BGW; x += 110) { px(bg, x, 0, 14, BGH, '#161a29'); px(bg, x, 0, 2, BGH, '#1c2133'); px(bg, x + 12, 0, 2, BGH, '#0e111b'); }
  for (const wx of [92, 204, 312]) {            // barred windows with a little night sky
    px(bg, wx, 40, 22, 34, '#0a0c14'); px(bg, wx + 2, 42, 18, 30, '#172640'); px(bg, wx + 2, 42, 18, 10, '#1d3152');
    px(bg, wx + 5, 46, 1, 1, '#cfe3ff'); px(bg, wx + 14, 50, 1, 1, '#9fb6dd'); px(bg, wx + 9, 58, 1, 1, '#9fb6dd');
    for (let i = 0; i < 3; i++) px(bg, wx + 5 + i * 5, 42, 1, 30, '#0a0c14');
  }
  // stone tiles
  for (let row = 0; row < ROWS; row++) for (let c = 0; c < COLS; c++) {
    if (!solidT(c, row)) continue;
    const x = c * T, y = row * T;
    px(tc, x, y, T, T, '#242a3b');
    px(tc, x, y + 4, T, 1, '#1b2030'); px(tc, x + ((row % 2) ? 2 : 6), y, 1, 4, '#1b2030'); px(tc, x + ((row % 2) ? 6 : 2), y + 5, 1, 3, '#1b2030');
    if (r() < 0.35) px(tc, x + 1 + ((r() * 5) | 0), y + 1 + ((r() * 5) | 0), 2, 1, '#2e354a');
    if (r() < 0.2) px(tc, x + ((r() * 6) | 0), y + 5 + ((r() * 2) | 0), 1, 1, '#151927');
    if (!solidT(c, row + 1)) px(tc, x, y + T - 1, T, 1, '#12151f');
    if (!solidT(c - 1, row)) px(tc, x, y, 1, T, '#323a52');
    if (!solidT(c + 1, row)) px(tc, x + T - 1, y, 1, T, '#161a26');
    if (!solidT(c, row - 1)) {
      px(tc, x, y, T, 1, '#6a7694'); px(tc, x, y + 1, T, 1, '#454e69');
      if (r() < 0.5) { const m = (r() * 6) | 0; px(tc, x + m, y - 1, 1, 1, '#4f9a62'); px(tc, x + m, y, 2, 1, '#3d7a4e'); }
      if (r() < 0.25) px(tc, x + ((r() * 7) | 0), y - 2, 1, 2, '#4f9a62');
    }
  }
  for (const L of spawns.lanterns) {             // chains up to the ceiling
    for (let y = L.y - 4; y > 0 && !solidAt(L.x, y); y -= 2) px(tc, L.x, y, 1, 1, '#4a4f5e');
    px(tc, L.x - 3, L.y - 3, 7, 1, '#2b2622'); px(tc, L.x - 3, L.y + 4, 7, 1, '#2b2622');
    px(tc, L.x - 3, L.y - 3, 1, 8, '#2b2622'); px(tc, L.x + 3, L.y - 3, 1, 8, '#2b2622');
  }
})();

// ---------- game state ----------
const KEYS = ['left', 'right', 'jump', 'dash', 'attack', 'restart', 't1', 't2', 't3', 't4', 'tall'];
const held = {}, prev = {}, pressed = {}, released = {}, latch = {};   // latch: a tap shorter than one frame still counts
const J = { hitstop: true, shake: true, particles: true, light: true };
if (params.get('juice') === '0') for (const k in J) J[k] = false;
let p, enemies, parts, flashes, frame, freeze, trauma, kills, cam, deadT;

function reset() {
  seed = 1337; frame = 0; freeze = 0; trauma = 0; kills = 0; deadT = 0;
  parts = []; flashes = [];
  p = { x: spawns.player.c * T, y: (spawns.player.r + 1) * T - 14, w: 8, h: 14, vx: 0, vy: 0, face: 1, ground: false, coyote: 0,
        jbuf: 0, atkBuf: 0, dashBuf: 0, airJumps: 1, airDash: true, dashT: 0, dashCd: 0, dashDir: 1, atkT: 0, atkN: 0, atkLen: 14, comboT: 0,
        hits: new Set(), hp: 5, inv: 0, hurtT: 0, dead: false, sx: 1, sy: 1, animT: 0 };
  enemies = spawns.enemies.map(s => newEnemy(s));
  cam = { x: clamp(p.x - W / 2, 0, WW - W), y: clamp(p.y - H / 2, 0, WH - H) };
}
function newEnemy(s) {
  return { spawn: s, x: s.c * T - 2, y: (s.r + 1) * T - 11, w: 12, h: 11, vx: 0, vy: 0, face: rnd() < 0.5 ? -1 : 1, state: 'patrol', t: 0, hp: 6,
           flash: 0, dead: false, respawn: 0, ground: false, sx: 1, sy: 1, animT: (rnd() * 60) | 0 };
}

// ---------- juice helpers ----------
const addShake = v => { trauma = Math.min(1, trauma + v); };
const addFreeze = n => { if (J.hitstop) freeze = Math.max(freeze, n); };
const addFlash = (x, y, r, life, color) => flashes.push({ x, y, r, life, max: life, color });
function part(o) { if (J.particles) parts.push(Object.assign({ vx: 0, vy: 0, grav: 0, drag: 1, size: 1, t: 0 }, o)); }
function dust(x, y, n, dir = 0, spread = 1) {
  for (let i = 0; i < n; i++) part({ type: 'dust', x: x + rr(-3, 3), y: y - rr(0, 2), vx: dir * rr(0.2, 0.9) + rr(-0.35, 0.35) * spread, vy: rr(-0.5, -0.05), drag: 0.92, life: rr(14, 26) | 0, size: rr(1.5, 3.2) });
}
function sparks(x, y, n, dir, color, speed = 3) {
  for (let i = 0; i < n; i++) { const a = rr(-0.9, 0.9) + (dir > 0 ? 0 : Math.PI), v = rr(0.4, 1) * speed; part({ type: 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.4, grav: 0.08, drag: 0.93, life: rr(8, 18) | 0, color }); }
}
function chunks(x, y, n, dir) {
  const cols = ['#6b2d52', '#9a4a78', '#4a1d3a', '#e7d6c4', '#a8ff60'];
  for (let i = 0; i < n; i++) part({ type: 'chunk', x: x + rr(-4, 4), y: y + rr(-4, 4), vx: dir * rr(0.5, 2.8) + rr(-1, 1), vy: rr(-3.6, -0.8), grav: 0.2, drag: 0.99, life: rr(40, 80) | 0, size: rr(1, 3) | 0 || 1, color: cols[(rnd() * cols.length) | 0] });
}

// ---------- player ----------
const SWING = { 1: { len: 14, a0: -1.9, a1: 0.9, R: 15 }, 2: { len: 14, a0: 1.0, a1: -1.7, R: 15 }, 3: { len: 22, a0: -2.6, a1: 1.3, R: 21 } };
function updatePlayer() {
  p.animT++;
  p.sx = lerp(p.sx, 1, 0.2); p.sy = lerp(p.sy, 1, 0.2);
  if (p.inv > 0) p.inv--; if (p.dashCd > 0) p.dashCd--; if (p.jbuf > 0) p.jbuf--; if (p.atkBuf > 0) p.atkBuf--; if (p.dashBuf > 0) p.dashBuf--;
  if (p.comboT > 0 && --p.comboT === 0) p.atkN = 0;
  const wasGround = p.ground, fallV = p.vy;

  if (p.dead) { p.vx *= 0.9; p.vy = Math.min(p.vy + 0.28, 5.5); }
  else if (p.hurtT > 0) { p.hurtT--; p.vy = Math.min(p.vy + 0.28, 5.5); }
  else {
    const dir = (held.right ? 1 : 0) - (held.left ? 1 : 0);
    const attacking = p.atkT > 0;
    // dash
    if (p.dashBuf > 0 && p.dashCd <= 0 && p.dashT <= 0 && (p.ground || p.airDash)) {
      p.dashT = 9; p.dashCd = 34; p.dashBuf = 0; p.dashDir = dir || p.face; p.face = p.dashDir; p.atkT = 0;
      if (!p.ground) p.airDash = false;
      p.sx = 1.35; p.sy = 0.72;
      dust(p.x + 4, p.y + p.h, 6, -p.dashDir, 0.6); addShake(0.12);
    }
    if (p.dashT > 0) {
      p.dashT--; p.vx = p.dashDir * 4.4; p.vy = 0;
      if (p.dashT % 2 === 0) part({ type: 'ghost', x: p.x, y: p.y, life: 12, pose: playerPose() });
      if (p.dashT === 0) p.vx = p.dashDir * 1.7;
    } else {
      const max = attacking && p.ground ? 0.5 : 1.7, acc = p.ground ? 0.32 : 0.22;
      p.vx += clamp(dir * max - p.vx, -acc, acc);
      if (dir && !attacking) p.face = dir;
      // jump (buffered, with coyote time and one air jump)
      if (p.jbuf > 0 && (p.coyote > 0 || p.airJumps > 0)) {
        if (p.coyote > 0) { p.vy = -5.0; dust(p.x + 4, p.y + p.h, 5); }
        else { p.airJumps--; p.vy = -4.4; part({ type: 'ring', x: p.x + 4, y: p.y + p.h, life: 12 }); }
        p.coyote = 0; p.jbuf = 0; p.sx = 0.72; p.sy = 1.3;
      }
      if (released.jump && p.vy < 0) p.vy *= 0.45;
      p.vy = Math.min(p.vy + (held.jump && Math.abs(p.vy) < 0.9 ? 0.16 : 0.28), 5.5);
      // light attack: 3-swing combo
      if (p.atkBuf > 0 && p.atkT <= 4) {
        p.atkN = p.comboT > 0 ? (p.atkN % 3) + 1 : 1;
        const sw = SWING[p.atkN];
        p.atkLen = sw.len; p.atkT = sw.len; p.comboT = sw.len + 18; p.atkBuf = 0; p.hits = new Set();
        if (dir) p.face = dir;
        if (p.ground) p.vx = p.face * (p.atkN === 3 ? 2.6 : 1.8);
        part({ type: 'slash', life: p.atkN === 3 ? 11 : 8, n: p.atkN, face: p.face });
        addFlash(p.x + 4 + p.face * 12, p.y + 5, 34, 6, '#9fe8ff');
      }
    }
    if (p.atkT > 0) {
      const f = p.atkLen - p.atkT; p.atkT--;
      if (f >= 2 && f <= 8) {
        const reach = p.atkN === 3 ? 30 : 24, hb = { x: p.face > 0 ? p.x + 2 : p.x + 6 - reach, y: p.y - 8, w: reach, h: 26 };
        for (const e of enemies) if (!e.dead && !p.hits.has(e) && overlap(hb, e)) { p.hits.add(e); hitEnemy(e, p.atkN); }
      }
    }
  }
  p.ground = false;
  if (moveX(p, p.vx)) p.vx = 0;
  if (moveY(p, p.vy)) { if (p.vy > 0) p.ground = true; p.vy = 0; }
  if (p.ground) {
    if (!wasGround) { p.sx = 1 + clamp(fallV * 0.09, 0.1, 0.4); p.sy = 1 - clamp(fallV * 0.08, 0.1, 0.35); dust(p.x + 4, p.y + p.h, 3 + (fallV | 0)); if (fallV > 4.5) addShake(0.15); }
    p.coyote = 6; p.airJumps = 1; p.airDash = true;
    if (!p.dead && Math.abs(p.vx) > 1.3 && frame % 8 === 0) dust(p.x + 4 - p.face * 3, p.y + p.h, 1, -p.face, 0.4);
  } else if (p.coyote > 0) p.coyote--;
}
function hurtPlayer(e) {
  p.hp--; p.inv = 70; p.hurtT = 14; p.atkT = 0; p.dashT = 0;
  const dir = p.x + 4 < e.x + 6 ? -1 : 1;
  p.vx = dir * 2.6; p.vy = -2.6;
  addFreeze(8); addShake(0.7); addFlash(p.x + 4, p.y + 6, 50, 10, '#ff5a4a'); sparks(p.x + 4, p.y + 6, 10, dir, '#ff8a6a');
  if (p.hp <= 0) { p.dead = true; p.hurtT = 0; addFreeze(16); addShake(1); sparks(p.x + 4, p.y + 6, 18, dir, '#ffd27a', 4); }
}
function playerPose() {
  let state = 'idle';
  if (p.dead) state = 'dead'; else if (p.dashT > 0) state = 'dash'; else if (p.atkT > 0) state = 'atk';
  else if (!p.ground) state = 'air'; else if (Math.abs(p.vx) > 0.4) state = 'run';
  return { face: p.face, state, t: p.animT, vy: p.vy, vx: p.vx, n: p.atkN, f: p.atkT > 0 ? (p.atkLen - p.atkT) / 9 : 0 };
}

// ---------- enemy: the Husk ----------
function hitEnemy(e, n) {
  const big = n === 3;
  e.hp -= big ? 2 : 1; e.flash = 7; e.state = 'stun'; e.t = big ? 28 : 16;
  e.vx = p.face * (big ? 3.2 : 1.7); e.vy = big ? -2.6 : -1.3; e.sx = 0.75; e.sy = 1.25;
  const hx = e.x + 6 - p.face * 4, hy = e.y + 4;
  addFreeze(big ? 9 : 5); addShake(big ? 0.55 : 0.32);
  addFlash(hx, hy, big ? 56 : 40, 8, '#ffffff'); sparks(hx, hy, big ? 14 : 8, p.face, '#fff3c4', big ? 4.2 : 3);
  if (e.hp <= 0) {
    e.dead = true; e.respawn = 200; kills++;
    addFreeze(12); addShake(0.8); addFlash(hx, hy, 70, 14, '#b8ff7a'); chunks(e.x + 6, e.y + 5, 16, p.face); sparks(hx, hy, 12, p.face, '#a8ff60', 4.5);
  }
}
function updateEnemy(e) {
  e.animT++;
  if (e.dead) {
    if (--e.respawn <= 0) { Object.assign(e, newEnemy(e.spawn)); dust(e.x + 6, e.y + e.h, 10, 0, 2); addFlash(e.x + 6, e.y + 5, 30, 12, '#a8ff60'); }
    return;
  }
  if (e.flash > 0) e.flash--;
  e.sx = lerp(e.sx, 1, 0.18); e.sy = lerp(e.sy, 1, 0.18);
  const dx = p.x + 4 - (e.x + 6), dy = p.y + 7 - (e.y + 5), adx = Math.abs(dx);
  const ahead = e.face > 0 ? e.x + e.w + 1 : e.x - 1;
  const edge = !solidAt(ahead, e.y + e.h + 2), wall = solidAt(ahead, e.y + e.h - 2);
  if (e.state === 'patrol') {
    const sees = !p.dead && adx < 72 && Math.abs(dy) < 22;
    if (sees) {
      e.face = dx > 0 ? 1 : -1;
      const ah2 = e.face > 0 ? e.x + e.w + 1 : e.x - 1;
      if (adx < 30) { e.state = 'windup'; e.t = 30; }
      else e.vx = !solidAt(ah2, e.y + e.h + 2) || solidAt(ah2, e.y + e.h - 2) ? 0 : e.face * 0.75;
    } else { if (e.ground && (edge || wall)) e.face = -e.face; e.vx = e.face * 0.4; }
  } else if (e.state === 'windup') {
    e.vx *= 0.8; e.sx = lerp(e.sx, 1.18, 0.3); e.sy = lerp(e.sy, 0.8, 0.3);
    if (--e.t <= 0) { e.state = 'lunge'; e.t = 14; e.vx = e.face * 3.1; e.vy = -1.7; e.sx = 1.3; e.sy = 0.8; dust(e.x + 6, e.y + e.h, 4, -e.face); }
  } else if (e.state === 'lunge') {
    e.vx *= 0.97;
    if (!p.dead && p.inv <= 0 && p.dashT <= 0 && overlap(e, p)) hurtPlayer(e);
    if (--e.t <= 0) { e.state = 'recover'; e.t = 38; }
  } else if (e.state === 'recover') { e.vx *= 0.85; if (--e.t <= 0) e.state = 'patrol'; }
  else if (e.state === 'stun') { e.vx *= 0.9; if (--e.t <= 0) e.state = 'patrol'; }
  e.vy = Math.min(e.vy + 0.28, 5.5);
  if (moveX(e, e.vx)) { if (e.state === 'patrol') e.face = -e.face; e.vx = 0; }
  const wasG = e.ground; e.ground = false;
  if (moveY(e, e.vy)) { if (e.vy > 0) { e.ground = true; if (!wasG && e.vy > 2) dust(e.x + 6, e.y + e.h, 3); } e.vy = 0; }
}

// ---------- particles ----------
function updateParts() {
  for (let i = parts.length - 1; i >= 0; i--) {
    const q = parts[i]; q.t++;
    if (--q.life <= 0) { parts.splice(i, 1); continue; }
    q.vy += q.grav; q.vx *= q.drag; q.vy *= q.drag;
    if (q.type === 'chunk') {
      if (solidAt(q.x + q.vx, q.y)) q.vx *= -0.5;
      if (solidAt(q.x, q.y + q.vy)) { q.vy *= -0.4; q.vx *= 0.7; }
    }
    q.x += q.vx; q.y += q.vy;
  }
  for (let i = flashes.length - 1; i >= 0; i--) if (--flashes[i].life <= 0) flashes.splice(i, 1);
}

// ---------- main tick ----------
function tick() {
  for (const k of KEYS) { pressed[k] = !!latch[k] || (!!held[k] && !prev[k]); latch[k] = false; released[k] = !held[k] && !!prev[k]; prev[k] = !!held[k]; }
  if (pressed.restart) { reset(); return; }
  if (pressed.t1) J.hitstop = !J.hitstop; if (pressed.t2) J.shake = !J.shake; if (pressed.t3) J.particles = !J.particles; if (pressed.t4) J.light = !J.light;
  if (pressed.tall) { const on = !(J.hitstop && J.shake && J.particles && J.light); for (const k in J) J[k] = on; }
  if (pressed.jump) p.jbuf = 7; if (pressed.attack) p.atkBuf = 10; if (pressed.dash) p.dashBuf = 6;
  trauma = Math.max(0, trauma - 0.035);
  if (freeze > 0) { freeze--; return; }          // hit-stop: the whole world holds for a few frames
  frame++;
  updatePlayer();
  for (const e of enemies) updateEnemy(e);
  updateParts();
  if (p.dead) deadT++;
  const tx = p.x + 4 + p.face * 22 - W / 2, ty = p.y + 2 - H / 2;
  cam.x = clamp(lerp(cam.x, tx, 0.09), 0, WW - W); cam.y = clamp(lerp(cam.y, ty, 0.12), 0, WH - H);
}

// ---------- sprites (drawn in code into a 32x32 scratch canvas, feet at 16,28, facing right) ----------
function drawPlayerSprite(c, o) {
  c.clearRect(0, 0, 32, 32); c.save();
  if (o.face < 0) { c.translate(32, 0); c.scale(-1, 1); }
  const t = o.t, CLOAK = '#2d3f63', SHADE = '#22304d', HOOD = '#3d5687', LEG = '#1a2233', SCARF = '#ff7a3d', GOLD = '#e8b04a', STEEL = '#d9f1ff';
  if (o.state === 'dead') {
    px(c, 8, 24, 14, 4, CLOAK); px(c, 8, 27, 14, 1, SHADE); px(c, 21, 22, 6, 6, HOOD); px(c, 24, 24, 3, 3, '#0e1220');
    for (let i = 0; i < 6; i++) px(c, 7 - i, 26 + (i > 3 ? 1 : 0), 1, 1, SCARF);
    line(c, 12, 23, 22, 21, STEEL); c.restore(); return;
  }
  const bob = o.state === 'run' ? (t >> 2) & 1 : o.state === 'idle' ? (Math.sin(t / 14) > 0.3 ? 1 : 0) : 0;
  const lean = o.state === 'dash' ? 2 : o.state === 'run' ? 1 : 0;
  // legs
  if (o.state === 'run') { const ph = (t >> 2) % 4, A = [[-2, 0], [0, -1], [2, 0], [0, -1]][ph], B = [[2, 0], [0, -1], [-2, 0], [0, -1]][ph]; px(c, 13 + A[0], 24 + A[1], 2, 4, LEG); px(c, 17 + B[0], 24 + B[1], 2, 4, LEG); }
  else if (o.state === 'air') { px(c, 13, 23, 2, o.vy < 0 ? 3 : 5, LEG); px(c, 17, 22, 2, o.vy < 0 ? 3 : 4, LEG); }
  else if (o.state === 'dash') { px(c, 9, 24, 5, 2, LEG); px(c, 11, 26, 4, 2, LEG); }
  else if (o.state === 'atk') { px(c, 12, 24, 2, 4, LEG); px(c, 19, 24, 2, 4, LEG); }
  else { px(c, 13, 24, 2, 4, LEG); px(c, 17, 24, 2, 4, LEG); }
  // scarf (trails behind, reacts to speed)
  const n = o.state === 'idle' ? 5 : 8;
  for (let i = 0; i < n; i++) { const u = i / n, y = 14 + bob + Math.round(Math.sin(t / 5 + i * 0.9) * 1.4 * u - o.vy * 0.5 * u); px(c, 11 + lean - i, y, 1, i < 3 ? 2 : 1, i % 3 === 2 ? '#d95f2a' : SCARF); }
  // cloak, belt, hood
  px(c, 12 + lean, 14 + bob, 8, 10, CLOAK); px(c, 12 + lean, 14 + bob, 2, 10, SHADE); px(c, 11 + lean, 21 + bob, 1, 3, SHADE); px(c, 12 + lean, 20 + bob, 8, 1, GOLD);
  px(c, 13 + lean, 8 + bob, 7, 7, HOOD); px(c, 12 + lean, 9 + bob, 1, 4, HOOD); px(c, 13 + lean, 8 + bob, 7, 1, '#5271ab'); px(c, 16 + lean, 10 + bob, 4, 4, '#0e1220'); px(c, 18 + lean, 11 + bob, 1, 2, '#ffe08a');
  // blade
  const hx = 18 + lean, hy = 18 + bob;
  if (o.state === 'atk') {
    const sw = SWING[o.n] || SWING[1], a = lerp(sw.a0, sw.a1, easeOut(o.f)), len = o.n === 3 ? 13 : 11;
    line(c, hx, hy, hx + Math.cos(a) * len, hy + Math.sin(a) * len, STEEL); line(c, hx, hy + 1, hx + Math.cos(a) * len * 0.6, hy + 1 + Math.sin(a) * len * 0.6, '#8fb7d6');
    px(c, hx - 1, hy - 1, 2, 2, GOLD);
  } else if (o.state === 'dash') { line(c, hx, hy, hx - 9, hy + 1, STEEL); px(c, hx, hy, 2, 2, GOLD); }
  else { line(c, hx - 3, hy + 1, hx - 9, hy + 6, STEEL); px(c, hx - 3, hy, 2, 2, GOLD); }
  c.restore();
}
function drawHuskSprite(c, e) {
  c.clearRect(0, 0, 32, 32); c.save();
  if (e.face < 0) { c.translate(32, 0); c.scale(-1, 1); }
  const ph = e.state === 'patrol' ? (e.animT >> 3) & 1 : 0, sh = e.state === 'windup' ? ((e.animT >> 1) & 1) : 0;
  c.translate(sh, 0);
  px(c, 11 + ph, 26, 2, 2, '#2a1420'); px(c, 15, 26 - ph, 2, 2 + ph, '#2a1420'); px(c, 19 - ph, 26, 2, 2, '#2a1420');
  px(c, 10, 19, 12, 7, '#6b2d52'); px(c, 11, 17, 10, 2, '#6b2d52'); px(c, 13, 16, 6, 1, '#6b2d52'); px(c, 10, 24, 12, 2, '#4a1d3a');
  px(c, 12, 17, 3, 1, '#9a4a78'); px(c, 16, 16, 3, 1, '#9a4a78'); px(c, 11, 19, 1, 2, '#9a4a78'); px(c, 10, 21, 2, 1, '#55213f'); px(c, 14, 20, 2, 1, '#55213f');
  px(c, 12, 15, 1, 2, '#e7d6c4'); px(c, 15, 14, 1, 2, '#e7d6c4'); px(c, 18, 15, 1, 2, '#e7d6c4');
  px(c, 18, 19, 3, 3, '#1a0a14'); px(c, 19, 23, 1, 1, '#e7d6c4'); px(c, 21, 23, 1, 1, '#e7d6c4');
  px(c, 19, 20, 2, 2, huskEye(e));
  c.restore();
}
const huskEye = e => (e.state === 'lunge' ? '#ff4a3d' : e.state === 'windup' ? ((e.animT >> 2) & 1 ? '#ff4a3d' : '#ffd23d') : e.state === 'stun' ? '#5c7a3a' : '#a8ff60');
function tinted(color) { tn.globalCompositeOperation = 'source-over'; tn.clearRect(0, 0, 32, 32); tn.drawImage(spr, 0, 0); tn.globalCompositeOperation = 'source-in'; tn.fillStyle = color; tn.fillRect(0, 0, 32, 32); return tintCv; }
function blit(img, fx, fy, sx, sy, ox = 0, oy = 0) {
  const w = Math.round(32 * sx), h = Math.round(32 * sy);
  b.drawImage(img, Math.round(fx - 16 * sx) + ox, Math.round(fy - 28 * sy) + oy, w, h);
}
function rimFor(cx, cy, lights) {      // which way is the strongest nearby light? -> 1px rim on that side
  let best = null, bv = 0;
  for (const L of lights) { if (L.self) continue; const d = Math.hypot(L.x - cx, L.y - cy), v = (1 - d / (L.r * 1.3)) * L.a; if (v > bv) { bv = v; best = L; } }
  if (!best) return null;
  const dx = best.x - cx, dy = best.y - cy, m = Math.hypot(dx, dy) || 1;
  return { ox: Math.round(dx / m), oy: Math.round(dy / m), color: best.color, a: clamp(bv * 1.4, 0, 0.95) };
}

// ---------- render ----------
function render() {
  const sh = J.shake ? trauma * trauma * 7 : 0;
  const cx = Math.round(cam.x + (Math.random() * 2 - 1) * sh), cy = Math.round(cam.y + (Math.random() * 2 - 1) * sh);
  b.globalCompositeOperation = 'source-over'; b.globalAlpha = 1;
  b.drawImage(bgCv, -Math.round(cx * 0.5), -Math.round(cy * 0.5));
  b.drawImage(tilesCv, -cx, -cy);

  // lights for this frame (world space)
  const flick = 1 + Math.sin(frame / 7) * 0.04 + Math.sin(frame / 2.3) * 0.02;
  const lights = spawns.lanterns.map(L => ({ x: L.x, y: L.y + 1, r: 96 * flick, a: 0.95, color: '#ffb45e' }));
  if (!p.dead || deadT < 60) lights.push({ x: p.x + 4, y: p.y + 5, r: 64, a: 0.8, color: '#8fb4ff', self: p });
  for (const e of enemies) if (!e.dead) lights.push({ x: e.x + 6 + e.face * 4, y: e.y + 4, r: e.state === 'windup' || e.state === 'lunge' ? 26 : 16, a: 0.6, color: huskEye(e), self: e });
  for (const f of flashes) { const u = f.life / f.max; lights.push({ x: f.x, y: f.y, r: f.r * (0.6 + 0.4 * u), a: u, color: f.color }); }

  // enemies
  for (const e of enemies) {
    if (e.dead) continue;
    drawHuskSprite(sp, e);
    const fx = e.x + 6 - cx, fy = e.y + e.h - cy, jit = freeze > 0 && e.flash > 0 ? Math.round(Math.random() * 2 - 1) : 0;
    if (J.light) { const rim = rimFor(e.x + 6, e.y + 5, lights); if (rim) { b.globalAlpha = rim.a; blit(tinted(rim.color), fx + jit, fy, e.sx, e.sy, rim.ox, rim.oy); b.globalAlpha = 1; } }
    blit(e.flash > 0 ? tinted('#ffffff') : spr, fx + jit, fy, e.sx, e.sy);
  }
  // player
  if (!(p.inv > 0 && !p.dead && (frame >> 2) & 1)) {
    drawPlayerSprite(sp, playerPose());
    const fx = p.x + 4 - cx, fy = p.y + p.h - cy;
    if (J.light) { const rim = rimFor(p.x + 4, p.y + 6, lights); if (rim) { b.globalAlpha = rim.a; blit(tinted(rim.color), fx, fy, p.sx, p.sy, rim.ox, rim.oy); b.globalAlpha = 1; } }
    blit(p.hurtT > 0 ? tinted('#ffffff') : spr, fx, fy, p.sx, p.sy);
  }
  // lit particles (dust, chunks)
  for (const q of parts) {
    if (q.type === 'dust') { const u = q.life / (q.life + q.t), s = Math.max(1, Math.round(q.size * (0.5 + u))); b.globalAlpha = 0.55 * u; px(b, Math.round(q.x - cx - s / 2), Math.round(q.y - cy - s / 2), s, s, '#c9cfdd'); }
    else if (q.type === 'chunk') { b.globalAlpha = Math.min(1, q.life / 15); px(b, Math.round(q.x - cx), Math.round(q.y - cy), q.size, q.size, q.color); }
  }
  b.globalAlpha = 1;

  // darkness with holes punched out by each light, then a little coloured glow
  if (J.light) {
    l.globalCompositeOperation = 'source-over'; l.clearRect(0, 0, W, H); l.fillStyle = 'rgba(4,6,15,0.6)'; l.fillRect(0, 0, W, H);
    l.globalCompositeOperation = 'destination-out';
    for (const L of lights) { const x = L.x - cx, y = L.y - cy, g = l.createRadialGradient(x, y, 0, x, y, L.r); g.addColorStop(0, `rgba(0,0,0,${L.a})`); g.addColorStop(0.5, `rgba(0,0,0,${L.a * 0.55})`); g.addColorStop(1, 'rgba(0,0,0,0)'); l.fillStyle = g; l.fillRect(x - L.r, y - L.r, L.r * 2, L.r * 2); }
    b.drawImage(lightCv, 0, 0);
    b.globalCompositeOperation = 'lighter';
    for (const L of lights) { const x = L.x - cx, y = L.y - cy, r = L.r * 0.8, g = b.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, L.color); g.addColorStop(1, '#000000'); b.globalAlpha = 0.2 * L.a; b.fillStyle = g; b.fillRect(x - r, y - r, r * 2, r * 2); }
    b.globalCompositeOperation = 'source-over'; b.globalAlpha = 1;
  }
  // glowing things, drawn on top of the darkness
  for (const L of spawns.lanterns) { px(b, L.x - 2 - cx, L.y - 2 - cy, 5, 6, '#ffcf7a'); px(b, L.x - 1 - cx, L.y - 1 - cy, 3, 3 + ((frame >> 3) & 1), '#fff4d2'); }
  for (const e of enemies) if (!e.dead && e.flash <= 0) px(b, Math.round(e.x + 6 + e.face * 3.5 - 1 - cx), Math.round(e.y + e.h - 8 * e.sy - cy), 2, 2, huskEye(e));
  for (const q of parts) {
    if (q.type === 'spark') { b.globalAlpha = Math.min(1, q.life / 6); line(b, q.x - cx, q.y - cy, q.x - q.vx * 2.2 - cx, q.y - q.vy * 2.2 - cy, q.color); }
    else if (q.type === 'ring') { const u = q.t / 12, rx = 3 + u * 9; b.globalAlpha = 1 - u; for (let a = 0; a < 6.28; a += 0.35) px(b, Math.round(q.x + Math.cos(a) * rx - cx), Math.round(q.y + Math.sin(a) * rx * 0.35 - cy), 1, 1, '#bfe6ff'); }
    else if (q.type === 'ghost') { drawPlayerSprite(sp, q.pose); b.globalAlpha = 0.5 * (q.life / 12); blit(tinted('#6fd6ff'), q.x + 4 - cx, q.y + 14 - cy, 1.2, 0.85); }
    else if (q.type === 'slash') {
      const sw = SWING[q.n], u = q.t / (q.life + q.t), head = lerp(sw.a0, sw.a1, easeOut(u * 1.7)), tail = lerp(sw.a0, sw.a1, easeOut(u * 1.7 - 0.55));
      const ox = p.x + 4 + q.face * 3 - cx, oy = p.y + 6 - cy, span = head - tail, steps = Math.max(1, Math.ceil(Math.abs(span) / 0.05));
      for (let i = 0; i <= steps; i++) {
        const k = i / steps, a = tail + span * k, th = 1 + k * (q.n === 3 ? 6 : 4) * (1 - u * 0.6);
        b.globalAlpha = (1 - u) * (0.35 + 0.65 * k);
        for (let r = sw.R - th; r <= sw.R; r++) px(b, Math.round(ox + Math.cos(a) * r * q.face), Math.round(oy + Math.sin(a) * r), 1, 1, k > 0.75 || r > sw.R - 1.5 ? '#ffffff' : '#8fe3ff');
      }
    }
  }
  b.globalAlpha = 1;
  if (p.dead) { b.globalAlpha = clamp(deadT / 90, 0, 0.55); px(b, 0, 0, W, H, '#1a0308'); b.globalAlpha = 1; }
  // health pips
  for (let i = 0; i < 5; i++) { px(b, 6 + i * 9, 6, 7, 6, '#0b0d14'); px(b, 7 + i * 9, 7, 5, 4, i < p.hp ? '#ff5a4a' : '#2a2f3d'); if (i < p.hp) px(b, 7 + i * 9, 7, 5, 1, '#ff9d8a'); }

  // scale up, then crisp text on the big canvas
  sctx.imageSmoothingEnabled = false;
  sctx.drawImage(buf, 0, 0, W * S, H * S);
  sctx.font = `600 ${S * 5}px ui-monospace, Menlo, Consolas, monospace`; sctx.textBaseline = 'top';
  sctx.textAlign = 'right'; sctx.fillStyle = '#e9edf7'; sctx.fillText(`HUSKS ${kills}`, (W - 6) * S, 6 * S);
  if (SHOW_HELP) {
    sctx.textAlign = 'left'; sctx.font = `${S * 4}px ui-monospace, Menlo, Consolas, monospace`; sctx.fillStyle = 'rgba(233,237,247,0.7)';
    sctx.fillText('A/D move · SPACE jump · SHIFT dash · J attack · R restart', 6 * S, (H - 9) * S);
    const tag = (k, on, name) => `${k}:${name} ${on ? 'on' : 'off'}`;
    sctx.textAlign = 'right'; sctx.fillText(`${tag(1, J.hitstop, 'hit-stop')}  ${tag(2, J.shake, 'shake')}  ${tag(3, J.particles, 'particles')}  ${tag(4, J.light, 'light')}  G:all`, (W - 6) * S, (H - 9) * S);
  }
  if (p.dead && deadT > 40) {
    sctx.textAlign = 'center'; sctx.fillStyle = '#ffe3dc'; sctx.font = `700 ${S * 12}px ui-monospace, Menlo, Consolas, monospace`; sctx.fillText('YOU FELL', (W / 2) * S, (H / 2 - 16) * S);
    sctx.font = `${S * 5}px ui-monospace, Menlo, Consolas, monospace`; sctx.fillText('press R to restart', (W / 2) * S, (H / 2 + 2) * S);
  }
}

// ---------- input ----------
const MAP = { KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right', Space: 'jump', KeyW: 'jump', ArrowUp: 'jump',
  ShiftLeft: 'dash', ShiftRight: 'dash', KeyK: 'dash', KeyJ: 'attack', KeyX: 'attack', KeyR: 'restart',
  Digit1: 't1', Digit2: 't2', Digit3: 't3', Digit4: 't4', KeyG: 'tall' };
addEventListener('keydown', e => { const k = MAP[e.code]; if (k) { if (!e.repeat) latch[k] = true; held[k] = true; e.preventDefault(); } });
addEventListener('keyup', e => { const k = MAP[e.code]; if (k) { held[k] = false; e.preventDefault(); } });
addEventListener('blur', () => { for (const k of KEYS) held[k] = false; });
screen.addEventListener('mousedown', () => { latch.attack = true; held.attack = true; });
addEventListener('mouseup', () => { held.attack = false; });

// ---------- boot ----------
reset();
window.GAME = {
  step(keys = {}) { for (const k of KEYS) held[k] = !!keys[k]; tick(); render(); },
  setJuice(on) { for (const k in J) J[k] = !!on; },
  state: () => ({ frame, freeze, kills, p: { x: p.x, y: p.y, face: p.face, ground: p.ground, hp: p.hp, dead: p.dead, atkT: p.atkT, dashCd: p.dashCd },
    enemies: enemies.map(e => ({ x: e.x, y: e.y, state: e.state, dead: e.dead, hp: e.hp })) }),
};
if (MANUAL) render();
else {
  let last = performance.now(), acc = 0;
  const loop = now => { acc += Math.min(100, now - last); last = now; let n = 0; while (acc >= 1000 / 60 && n++ < 5) { tick(); acc -= 1000 / 60; } render(); requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
}
})();
