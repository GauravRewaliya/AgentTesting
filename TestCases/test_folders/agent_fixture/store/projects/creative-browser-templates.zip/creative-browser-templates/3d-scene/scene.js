// Moonlit Ruins: a small stylized 3D scene you can orbit. Three.js (WebGL), all geometry made in code.
// Everything that moves is a function of time and repeats every LOOP seconds, so the animation loops seamlessly.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const params = new URLSearchParams(location.search);
const STEP = params.has('step');                // step mode: no clock, frames come only from SCENE.frame(t, cam)
if (params.get('ui') === '0') document.body.classList.add('noui');
const LOOP = 16, TAU = Math.PI * 2, W = TAU / LOOP;

let seed = 20261110;
const rnd = () => { seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const rr = (a, b) => a + rnd() * (b - a);

// ---------- renderer, camera, controls ----------
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: STEP });
renderer.setPixelRatio(STEP ? 1 : Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;        // r187 dropped PCFSoft; PCF with shadow.radius is its soft filter now
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.25;
document.body.prepend(renderer.domElement);

const scene = new THREE.Scene();
const FOG = new THREE.FogExp2(0x1b1f3a, 0.032);
scene.fog = FOG;
const camera = new THREE.PerspectiveCamera(42, innerWidth / innerHeight, 0.1, 300);
const TARGET = new THREE.Vector3(0, 2.0, 0), HOME = { az: 0.5, el: 0.22, dist: 15 };
function placeCamera({ az = HOME.az, el = HOME.el, dist = HOME.dist, ty = TARGET.y } = {}) {
  camera.position.set(Math.sin(az) * Math.cos(el) * dist, ty + Math.sin(el) * dist, Math.cos(az) * Math.cos(el) * dist);
  camera.lookAt(0, ty, 0);
}
placeCamera();
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(TARGET); controls.enableDamping = true; controls.dampingFactor = 0.08;
controls.minDistance = 5; controls.maxDistance = 30; controls.maxPolarAngle = Math.PI * 0.495;   // never below the ground
controls.autoRotateSpeed = 60 / LOOP;                                                              // one turn per loop
controls.update();

// ---------- lights ----------
const hemi = new THREE.HemisphereLight(0x5a66b8, 0x1c1626, 0.75);
scene.add(hemi);
const moon = new THREE.DirectionalLight(0xa9bcff, 3.0);            // the directional light
const MOON_DIR = new THREE.Vector3(-0.55, 0.62, -0.56).normalize();
moon.position.copy(MOON_DIR).multiplyScalar(30);
moon.castShadow = true;
moon.shadow.mapSize.set(2048, 2048);
Object.assign(moon.shadow.camera, { left: -15, right: 15, top: 15, bottom: -15, near: 1, far: 70 });
moon.shadow.bias = -0.0004; moon.shadow.normalBias = 0.04; moon.shadow.radius = 4;
scene.add(moon);
const crystalLight = new THREE.PointLight(0x5ff2e0, 34, 16, 1.8);  // point light 1: the crystal (casts shadows)
crystalLight.castShadow = true; crystalLight.shadow.mapSize.set(1024, 1024); crystalLight.shadow.bias = -0.003; crystalLight.shadow.camera.near = 0.3; crystalLight.shadow.camera.far = 16;
scene.add(crystalLight);
const fires = [];                                                    // point lights 2 and 3: braziers

// ---------- materials ----------
const flat = (color, extra = {}) => new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: 0.92, metalness: 0, ...extra });
const STONE = [flat(0x9a97a6), flat(0x858292), flat(0xaaa7b4), flat(0x7c8590)];
const stone = () => STONE[(rnd() * STONE.length) | 0];
const shadowed = (m, cast = true, recv = true) => { m.castShadow = cast; m.receiveShadow = recv; return m; };
function blob(size, stops) {      // soft round sprite texture, drawn on a canvas
  const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d'), g = x.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  stops.forEach(([o, col]) => g.addColorStop(o, col)); x.fillStyle = g; x.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
const GLOW = blob(64, [[0, 'rgba(255,255,255,1)'], [0.25, 'rgba(255,255,255,0.55)'], [1, 'rgba(255,255,255,0)']]);
const SOFT = blob(128, [[0, 'rgba(255,255,255,0.9)'], [0.5, 'rgba(255,255,255,0.3)'], [1, 'rgba(255,255,255,0)']]);

// ---------- sky, stars, moon ----------
const sky = new THREE.Mesh(new THREE.SphereGeometry(200, 32, 16), new THREE.ShaderMaterial({
  side: THREE.BackSide, depthWrite: false, fog: false,
  uniforms: { top: { value: new THREE.Color(0x070a1c) }, mid: { value: new THREE.Color(0x1b1f3a) }, low: { value: new THREE.Color(0x4a3a66) } },
  vertexShader: 'varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: 'uniform vec3 top; uniform vec3 mid; uniform vec3 low; varying vec3 vP; void main(){ float h = normalize(vP).y; vec3 c = mix(low, mid, smoothstep(-0.05, 0.22, h)); c = mix(c, top, smoothstep(0.2, 0.75, h)); gl_FragColor = vec4(c, 1.0); }',
}));
scene.add(sky);
{
  const n = 420, pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { const a = rnd() * TAU, h = rr(0.12, 1), r = Math.sqrt(1 - h * h); pos.set([Math.cos(a) * r * 180, h * 180, Math.sin(a) * r * 180], i * 3); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  scene.add(new THREE.Points(g, new THREE.PointsMaterial({ size: 2.8, map: GLOW, transparent: true, depthWrite: false, fog: false, color: 0xcfd8ff, opacity: 0.9 })));
  const disc = new THREE.Sprite(new THREE.SpriteMaterial({ map: blob(128, [[0, 'rgba(255,255,255,1)'], [0.32, 'rgba(255,255,255,1)'], [0.36, 'rgba(190,205,255,0.35)'], [1, 'rgba(160,180,255,0)']]), fog: false, depthWrite: false, color: 0xe6ecff }));
  disc.position.copy(MOON_DIR).multiplyScalar(170); disc.scale.setScalar(34); scene.add(disc);
}

// ---------- ground ----------
const groundH = (x, z) => { const r = Math.hypot(x, z), k = THREE.MathUtils.smoothstep(r, 5.6, 11); return k * (Math.sin(x * 0.45 + 1.3) * Math.cos(z * 0.38) * 0.55 + Math.sin(x * 1.3 + z * 0.9) * 0.14 + 0.1); };
{
  const g = new THREE.PlaneGeometry(120, 120, 110, 110); g.rotateX(-Math.PI / 2);
  const p = g.attributes.position, col = new Float32Array(p.count * 3), a = new THREE.Color(0x35503f), b = new THREE.Color(0x4a6648), c = new THREE.Color();
  for (let i = 0; i < p.count; i++) { const x = p.getX(i) + rr(-0.2, 0.2), z = p.getZ(i) + rr(-0.2, 0.2); p.setXYZ(i, x, groundH(x, z), z); c.copy(a).lerp(b, rnd()); col.set([c.r, c.g, c.b], i * 3); }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.computeVertexNormals();
  scene.add(shadowed(new THREE.Mesh(g, flat(0xffffff, { vertexColors: true })), false, true));
}

// ---------- the ruins ----------
const ruins = new THREE.Group(); scene.add(ruins);
const add = (geo, mat, x, y, z, parent = ruins) => { const m = shadowed(new THREE.Mesh(geo, mat)); m.position.set(x, y, z); parent.add(m); return m; };
{ // paving
  const tiles = [];
  for (let x = -6; x <= 6; x++) for (let z = -6; z <= 6; z++) if (Math.hypot(x, z) < 6.2 && rnd() > 0.1) tiles.push([x, z]);
  const inst = shadowed(new THREE.InstancedMesh(new THREE.BoxGeometry(0.93, 0.16, 0.93), flat(0xffffff), tiles.length), false, true), o = new THREE.Object3D(), c = new THREE.Color();
  tiles.forEach(([x, z], i) => { o.position.set(x + rr(-0.02, 0.02), 0.03 + rr(0, 0.05), z + rr(-0.02, 0.02)); o.rotation.set(rr(-0.03, 0.03), rr(-0.04, 0.04), rr(-0.03, 0.03)); o.updateMatrix(); inst.setMatrixAt(i, o.matrix); inst.setColorAt(i, c.setHex(0x7f7c8c).offsetHSL(0, 0, rr(-0.06, 0.07))); });
  ruins.add(inst);
}
const DRUM = 0.62, colTop = n => 0.28 + n * DRUM + 0.34;
function column(x, z, drums, capital, tiltTop = 0) {
  const g = new THREE.Group(); g.position.set(x, 0.08, z); g.rotation.y = rr(0, TAU); ruins.add(g);
  add(new THREE.BoxGeometry(1.08, 0.28, 1.08), stone(), 0, 0.14, 0, g);
  for (let i = 0; i < drums; i++) { const d = add(new THREE.CylinderGeometry(0.37, 0.39, DRUM - 0.02, 10), stone(), rr(-0.02, 0.02), 0.28 + DRUM * (i + 0.5), rr(-0.02, 0.02), g); d.rotation.y = rr(0, TAU);
    if (i === drums - 1 && tiltTop) { d.rotation.z = tiltTop; d.position.x += 0.08; } }
  if (capital) { add(new THREE.CylinderGeometry(0.5, 0.38, 0.14, 10), stone(), 0, 0.28 + drums * DRUM + 0.07, 0, g); add(new THREE.BoxGeometry(1.02, 0.2, 1.02), stone(), 0, 0.28 + drums * DRUM + 0.24, 0, g); }
}
const RING = 4.6, ringPos = i => [Math.sin(i * TAU / 8) * RING, Math.cos(i * TAU / 8) * RING];
const COLS = { 1: [2, false, 0.14], 2: [7, true], 3: [7, true], 4: [7, true], 5: [7, true], 6: [4, false, -0.1], 7: [6, false] };   // slot 0 (facing the camera) is left open
for (const i in COLS) { const [x, z] = ringPos(+i); column(x, z, ...COLS[i]); }
for (const [a, b] of [[3, 4], [4, 5]]) {     // lintels across the back
  const [ax, az] = ringPos(a), [bx, bz] = ringPos(b), len = Math.hypot(bx - ax, bz - az) + 1.0;
  const m = add(new THREE.BoxGeometry(len, 0.5, 0.86), stone(), (ax + bx) / 2, 0.08 + colTop(7) + 0.25, (az + bz) / 2); m.rotation.y = -Math.atan2(bz - az, bx - ax);
}
{ const [x, z] = ringPos(2), m = add(new THREE.BoxGeometry(2.2, 0.5, 0.86), stone(), x + 0.5, 0.08 + colTop(7) + 0.25, z - 0.35); m.rotation.set(0.05, 0.9, -0.06); }   // a broken lintel stub
{ const [x, z] = ringPos(1);                  // the fallen column, lying in the grass
  for (let i = 0; i < 4; i++) { const d = add(new THREE.CylinderGeometry(0.37, 0.39, DRUM - 0.02, 10), stone(), x + 1.5 + i * 0.72 + rr(-0.05, 0.05), 0.42, z + 0.8 + i * 0.3 + rr(-0.08, 0.08)); d.rotation.set(rr(-0.08, 0.08), 0.4 + rr(-0.15, 0.15), Math.PI / 2 + rr(-0.08, 0.08)); } }
for (let row = 0; row < 5; row++) for (let c = -5; c <= 5; c++) {     // broken wall behind
  if (rnd() < 0.08 + row * 0.16 + Math.abs(c) * 0.035) continue;
  add(new THREE.BoxGeometry(0.98, 0.56, 0.7), stone(), c * 1.0 + (row % 2) * 0.5 + rr(-0.03, 0.03), 0.3 + row * 0.57, -7.4 + rr(-0.04, 0.04)).rotation.y = rr(-0.04, 0.04);
}
for (let i = 0; i < 34; i++) { const a = rnd() * TAU, r = rr(2.6, 8.5), s = rr(0.1, 0.34), m = add(new THREE.DodecahedronGeometry(s, 0), stone(), Math.sin(a) * r, s * 0.6 + groundH(Math.sin(a) * r, Math.cos(a) * r), Math.cos(a) * r); m.rotation.set(rnd() * 3, rnd() * 3, rnd() * 3); }
add(new THREE.CylinderGeometry(1.9, 2.0, 0.26, 8), STONE[1], 0, 0.22, 0);       // dais
add(new THREE.CylinderGeometry(1.3, 1.4, 0.26, 8), STONE[0], 0, 0.48, 0);
add(new THREE.BoxGeometry(0.62, 0.85, 0.62), STONE[2], 0, 1.03, 0).rotation.y = 0.4;
add(new THREE.BoxGeometry(0.8, 0.12, 0.8), STONE[0], 0, 1.5, 0).rotation.y = 0.4;

// ---------- floating crystal + orbiting shards (the looping motion) ----------
const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.42, 0), new THREE.MeshStandardMaterial({ color: 0x7ff5e6, emissive: 0x1fcfba, emissiveIntensity: 1.1, flatShading: true, roughness: 0.25 }));
crystal.scale.y = 1.7; scene.add(crystal);
const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: GLOW, color: 0x5ff2e0, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.55 }));
halo.scale.setScalar(3.4); scene.add(halo);
const shards = [];
for (let i = 0; i < 9; i++) {
  const big = i < 4, m = shadowed(new THREE.Mesh(big ? new THREE.DodecahedronGeometry(rr(0.2, 0.3), 0) : new THREE.OctahedronGeometry(rr(0.07, 0.13), 0), big ? stone() : flat(0x9fe9df, { emissive: 0x2bbfae, emissiveIntensity: 0.9 })), true, false);
  scene.add(m); shards.push({ m, r: big ? rr(2.3, 2.9) : rr(0.9, 1.5), y: big ? rr(1.6, 3.4) : rr(2.2, 3.6), ph: (i / (big ? 4 : 5)) * TAU + rr(-0.2, 0.2), dir: big ? 1 : -2, bob: (2 + ((rnd() * 3) | 0)), bp: rnd() * TAU, amp: big ? 0.22 : 0.12 });
}

// ---------- braziers (warm point lights with a looping flicker) ----------
for (const sx of [-1, 1]) {
  const x = sx * 3.3, z = 4.4;
  add(new THREE.CylinderGeometry(0.16, 0.26, 1.0, 8), STONE[1], x, 0.6, z); add(new THREE.CylinderGeometry(0.42, 0.2, 0.26, 8), STONE[0], x, 1.22, z);
  const flame = new THREE.Mesh(new THREE.IcosahedronGeometry(0.15, 0), new THREE.MeshBasicMaterial({ color: 0xff7a1a, toneMapped: false })); flame.position.set(x, 1.46, z); scene.add(flame);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: GLOW, color: 0xff8a3c, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.6 })); glow.position.set(x, 1.5, z); glow.scale.setScalar(2.2); scene.add(glow);
  const light = new THREE.PointLight(0xff8a3c, 16, 12, 1.8); light.position.set(x, 1.7, z); scene.add(light);
  fires.push({ flame, glow, light, ph: sx * 1.7 });
}

// ---------- trees + grass (wind sway) ----------
const trees = [];
for (const [x, z, s] of [[-13.5, -4, 1.5], [-12, 8, 1.2], [13, -6, 1.6], [14.5, 5, 1.3], [-5, -15, 1.8], [7, -15.5, 1.5], [-17, 2, 1.7], [16, -12, 1.9], [-8, 14.5, 1.3], [9, 15, 1.4], [0.5, -18.5, 2.0]]) {
  const g = new THREE.Group(); g.position.set(x, groundH(x, z) - 0.1, z); g.scale.setScalar(s); scene.add(g);
  add(new THREE.CylinderGeometry(0.14, 0.26, 2.0, 6), flat(0x3a2c2e), 0, 1.0, 0, g);
  const tiers = [];
  for (let i = 0; i < 3; i++) { const t = add(new THREE.ConeGeometry(1.25 - i * 0.3, 1.5, 7), flat(i % 2 ? 0x2c5a4e : 0x244a44), 0, 2.3 + i * 0.95, 0, g); t.rotation.y = rnd() * TAU; tiers.push(t); }
  trees.push({ g, tiers, ph: rnd() * TAU });
}
const BLADES = 1500, blades = [], grass = new THREE.InstancedMesh(new THREE.ConeGeometry(0.04, 0.34, 4).translate(0, 0.17, 0), flat(0xffffff, { emissive: 0x16261c }), BLADES), dummy = new THREE.Object3D();
{ const c = new THREE.Color(); let i = 0;
  while (i < BLADES) { const a = rnd() * TAU, r = i < 240 ? rr(1.8, 6.2) : rr(6.2, 15), x = Math.sin(a) * r + (i < 240 ? 0.5 : 0), z = Math.cos(a) * r + (i < 240 ? 0.5 : 0);   // some blades poke up between the paving
    blades.push({ x, y: groundH(x, z) + (i < 240 ? 0.08 : 0), z, ry: rnd() * TAU, s: rr(0.5, 1.2), lean: rr(-0.1, 0.1) }); grass.setColorAt(i, c.setHex(0x6f9d68).offsetHSL(rr(-0.03, 0.03), 0, rr(-0.07, 0.08))); i++; } }
grass.frustumCulled = false; scene.add(grass);

// ---------- ambient particles: fireflies/dust + low mist ----------
const FLIES = 320, flyBase = [], flyGeo = new THREE.BufferGeometry();
flyGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(FLIES * 3), 3)); flyGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(FLIES * 3), 3));
for (let i = 0; i < FLIES; i++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * 11; flyBase.push({ x: Math.sin(a) * r, y: rr(0.4, 5), z: Math.cos(a) * r, k: [1 + ((rnd() * 3) | 0), 1 + ((rnd() * 3) | 0), 1 + ((rnd() * 3) | 0)], p: [rnd() * TAU, rnd() * TAU, rnd() * TAU], tw: 3 + ((rnd() * 6) | 0), warm: rnd() < 0.7 }); }
const flies = new THREE.Points(flyGeo, new THREE.PointsMaterial({ size: 0.15, map: GLOW, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
flies.frustumCulled = false; scene.add(flies);
const mist = [];
for (let i = 0; i < 16; i++) { const a = rnd() * TAU, r = rr(3, 13), s = new THREE.Sprite(new THREE.SpriteMaterial({ map: SOFT, color: 0x7f8fd0, transparent: true, opacity: rr(0.08, 0.16), depthWrite: false }));
  s.scale.set(rr(7, 12), rr(2.2, 3.4), 1); scene.add(s); mist.push({ s, x: Math.sin(a) * r, y: rr(0.5, 1.1), z: Math.cos(a) * r, ph: rnd() * TAU, amp: rr(0.8, 2) }); }
const particleGroup = [flies, ...mist.map(m => m.s)];

// ---------- everything that moves, as a function of time ----------
function update(t) {
  const cy = 2.75 + Math.sin(W * 2 * t) * 0.16;
  crystal.position.set(0, cy, 0); crystal.rotation.y = W * 2 * t; crystal.rotation.z = Math.sin(W * t) * 0.12;
  halo.position.copy(crystal.position); halo.material.opacity = 0.5 + Math.sin(W * 4 * t) * 0.08;
  crystalLight.position.copy(crystal.position); crystalLight.intensity = 34 * (1 + Math.sin(W * 4 * t) * 0.1);
  for (const s of shards) { const a = s.ph + W * s.dir * t; s.m.position.set(Math.sin(a) * s.r, s.y + Math.sin(W * s.bob * t + s.bp) * s.amp, Math.cos(a) * s.r); s.m.rotation.set(W * 2 * t + s.ph, W * 3 * t, s.bp); }
  for (const f of fires) { const k = 1 + 0.2 * Math.sin(W * 83 * t + f.ph) + 0.13 * Math.sin(W * 131 * t + f.ph * 2) + 0.07 * Math.sin(W * 211 * t + 0.5);
    f.light.intensity = 16 * k; f.flame.scale.set(1, 0.9 + 0.5 * k, 1); f.glow.material.opacity = 0.42 * k; }
  for (const tr of trees) { tr.g.rotation.z = Math.sin(W * 2 * t + tr.ph) * 0.025; tr.g.rotation.x = Math.sin(W * 3 * t + tr.ph * 1.7) * 0.018; tr.tiers.forEach((m, i) => { m.rotation.z = Math.sin(W * 4 * t + tr.ph + i) * 0.03 * (i + 1); }); }
  for (let i = 0; i < BLADES; i++) { const b = blades[i]; dummy.position.set(b.x, b.y, b.z); dummy.rotation.set(b.lean + Math.sin(W * 5 * t + b.x * 0.55 + b.z * 0.4) * 0.22 + Math.sin(W * 11 * t + b.x) * 0.05, b.ry, 0.12 + Math.sin(W * 5 * t + b.x * 0.55 + b.z * 0.4 + 0.6) * 0.12, 'YXZ'); dummy.scale.setScalar(b.s); dummy.updateMatrix(); grass.setMatrixAt(i, dummy.matrix); }
  grass.instanceMatrix.needsUpdate = true;
  const pos = flyGeo.attributes.position, col = flyGeo.attributes.color;
  for (let i = 0; i < FLIES; i++) { const f = flyBase[i], tw = 0.35 + 0.65 * Math.max(0, Math.sin(W * f.tw * t + f.p[0]));
    pos.setXYZ(i, f.x + Math.sin(W * f.k[0] * t + f.p[0]) * 0.9, f.y + Math.sin(W * f.k[1] * t + f.p[1]) * 0.5, f.z + Math.cos(W * f.k[2] * t + f.p[2]) * 0.9);
    f.warm ? col.setXYZ(i, 0.95 * tw, 0.62 * tw, 0.12 * tw) : col.setXYZ(i, 0.15 * tw, 0.85 * tw, 0.7 * tw); }
  pos.needsUpdate = true; col.needsUpdate = true;
  for (const m of mist) m.s.position.set(m.x + Math.sin(W * t + m.ph) * m.amp, m.y, m.z + Math.cos(W * t + m.ph) * m.amp * 0.6);
}

// ---------- toggles (for before/after) ----------
const T = { shadows: true, fog: true, particles: true, pointLights: true, motion: true, autoOrbit: false };
function apply() {
  moon.castShadow = T.shadows; crystalLight.castShadow = T.shadows;
  const fog = T.fog ? FOG : null; if (scene.fog !== fog) { scene.fog = fog; scene.traverse(o => { if (o.material) o.material.needsUpdate = true; }); }
  for (const p of particleGroup) p.visible = T.particles;
  crystalLight.visible = T.pointLights; for (const f of fires) f.light.visible = T.pointLights;
  controls.autoRotate = T.autoOrbit;
  document.querySelectorAll('#toggles button').forEach(b => b.classList.toggle('on', T[b.dataset.k]));
}
const toggle = k => { T[k] = !T[k]; apply(); };
document.querySelectorAll('#toggles button').forEach(b => { b.onclick = () => toggle(b.dataset.k); });
addEventListener('keydown', e => { const k = { Digit1: 'shadows', Digit2: 'fog', Digit3: 'particles', Digit4: 'pointLights', Digit5: 'motion', KeyA: 'autoOrbit' }[e.code]; if (k) toggle(k);
  if (e.code === 'KeyR') { controls.target.copy(TARGET); placeCamera(); controls.update(); } });
apply();
document.getElementById('tech').textContent = `Three.js r${THREE.REVISION} · WebGL`;
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });

// ---------- run ----------
let time = 0, frames = 0, fps = 0, fpsT = performance.now(), held = 0;
update(0);
if (!STEP) {
  let last = performance.now();
  renderer.setAnimationLoop(() => {
    const n = performance.now(), dt = Math.min(0.1, (n - last) / 1000); last = n; if (T.motion) held += dt; time = held % LOOP;
    update(time); controls.update(); renderer.render(scene, camera);
    frames++; const now = performance.now(); if (now - fpsT >= 1000) { fps = (frames * 1000) / (now - fpsT); frames = 0; fpsT = now; }
  });
} else renderer.render(scene, camera);

// debug and automation hooks
const gl = renderer.getContext(), dbg = gl.getExtension('WEBGL_debug_renderer_info');
window.SCENE = {
  LOOP, T, toggle,
  frame(t, cam) { time = t; update(((t % LOOP) + LOOP) % LOOP); placeCamera(cam); renderer.render(scene, camera); },
  info: () => ({ three: THREE.REVISION, gpu: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'unknown', calls: renderer.info.render.calls, triangles: renderer.info.render.triangles,
    shadowType: renderer.shadowMap.type === THREE.PCFShadowMap ? 'PCF (filtered, radius ' + moon.shadow.radius + ')' : String(renderer.shadowMap.type), shadowsOn: renderer.shadowMap.enabled && moon.castShadow,
    directionalLights: 1, pointLights: 1 + fires.length, shadowCasters: [moon, crystalLight].filter(l => l.castShadow).length, fog: scene.fog ? 'FogExp2 ' + scene.fog.density : 'off', fireflies: FLIES, mistSprites: mist.length, grassBlades: BLADES, fps: +fps.toFixed(1) }),
  state: () => ({ time: +time.toFixed(3), cam: camera.position.toArray().map(v => +v.toFixed(3)), camDist: +camera.position.distanceTo(controls.target).toFixed(3), crystalY: +crystal.position.y.toFixed(4), shard0: shards[0].m.position.toArray().map(v => +v.toFixed(4)),
    fire0: +fires[0].light.intensity.toFixed(4), fly0: [flyGeo.attributes.position.getX(0), flyGeo.attributes.position.getY(0)].map(v => +v.toFixed(4)), tree0: +trees[0].g.rotation.z.toFixed(5) }),
};
