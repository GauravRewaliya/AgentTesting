# Moonlit Ruins — orbitable 3D scene

A small stylised night scene you can spin around in the browser: broken stone columns, a floating crystal, two fire braziers, grass, fog, mist and fireflies under a moon.

Built with Three.js (WebGL). Every model is made in code from simple shapes; there are no model or texture files.

## Run it

Serve the folder from a local web server. The scene uses JavaScript modules, which browsers won't load straight from disk.

```bash
python3 -m http.server 8000
```

Then open http://localhost:8000.

## Controls

| Action | Input |
|---|---|
| Orbit | Drag |
| Zoom | Scroll |
| Pan | Right-drag |
| Reset camera | R |
| Toggle shadows / fog / particles / point lights / motion | 1 / 2 / 3 / 4 / 5 |
| Auto-orbit | A |

The buttons in the top right do the same toggles.

## What's in the scene

- **Lights**: a soft sky light, a moon (directional light) that casts shadows, a pulsing point light inside the crystal that also casts shadows, and two flickering fire lights.
- **Atmosphere**: fog, 16 drifting mist sprites and 320 fireflies.
- **Ground**: stone tiles and 1,500 grass blades drawn in one batch, swaying in the wind.
- **Motion**: the crystal floats and spins, shards orbit it, trees and grass sway, and fires flicker. Everything repeats every 16 seconds, so the animation loops seamlessly.

## URL options

| Option | What it does |
|---|---|
| `?ui=0` | Hide all on-screen text and buttons |
| `?step=1` | Step mode: no clock. Frames come only from `SCENE.frame(t, camera)` in code |

`window.SCENE` also has `toggle(name)`, `info()` and `state()` for scripting.

## What's inside

- `index.html`: the page and buttons.
- `scene.js`: the whole scene.
- `vendor/`: a local copy of Three.js (r187) and its OrbitControls, so nothing loads from the internet.

## Make it yours

- **Fog, sky colours and light strength** are set near the top of `scene.js` (`FOG`, the sky shader colours, `hemi` and `moon`).
- **Layout**: each part of the scene has its own labelled section in `scene.js`. Tree positions are a plain list of `[x, z, size]`, and the braziers sit at `x = ±3.3`.
- **Loop length**: change `LOOP` (seconds). Motion stays seamless at any length.

## Notes

- Tested in desktop Chrome on a fast GPU. Older or integrated graphics may run slower; turn shadows off (key 1) to help.
- Shadows are filtered, not true soft shadows.
- A small scene, not a full game environment.

## License

The scene code is free to use, change and share for any purpose, personal or commercial. No credit needed.

Three.js is © the three.js authors and released under the MIT License. Keep `vendor/LICENSE-three.txt` with it.
