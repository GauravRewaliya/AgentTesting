// Grain Cloud: a granular synthesizer demo. Sound: Web Audio API. Picture: Canvas 2D. No libraries.
(() => {
'use strict';
const $ = id => document.getElementById(id);
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

// ---------- audio graph ----------
const AC = window.AudioContext || window.webkitAudioContext;
const ac = new AC();
const wet = ac.createGain(), dry = ac.createGain(), grainBus = ac.createGain(), out = ac.createDynamicsCompressor(), analyser = ac.createAnalyser();
grainBus.connect(wet); wet.connect(out); dry.connect(out); out.connect(ac.destination); out.connect(analyser);
out.threshold.value = -10; out.ratio.value = 6; analyser.fftSize = 1024;
const HANN = new Float32Array(64).map((_, i) => 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / 63));   // each grain fades in and out

const P = { size: 120, position: 30, spray: 15, density: 25, pitch: 0, reverse: 10, mix: 100 };
const FMT = { size: v => v + ' ms', position: v => (+v).toFixed(0) + ' %', spray: v => v + ' %', density: v => v + ' /s',
  pitch: v => (v > 0 ? '+' : '') + v + ' st', reverse: v => v + ' %', mix: v => v + ' % wet' };
const stats = { scheduled: 0, reversed: 0, lastRate: 1, lastDur: 0, lastPos: 0 };
let buffer = null, revBuffer = null, peaks = null, sourceName = '', isFallback = true;
let playing = false, timer = 0, nextTime = 0, drySrc = null;
const grains = [];           // one visual record per audio grain

// ---------- sources ----------
function builtIn(kind) {
  const sr = ac.sampleRate, len = sr * 3, buf = ac.createBuffer(1, len, sr), d = buf.getChannelData(0);
  if (kind === 'tone') {
    const notes = [220, 261.63, 329.63, 440, 392, 329.63];
    for (let i = 0; i < len; i++) { const t = i / sr, n = Math.min(5, Math.floor(t / 0.5)), u = t - n * 0.5, f = notes[n];
      d[i] = (Math.sin(2 * Math.PI * f * t) * 0.5 + Math.sin(2 * Math.PI * f * 2 * t) * 0.2 + Math.sin(2 * Math.PI * f * 3 * t) * 0.1) * Math.exp(-u * 3) * Math.min(1, u * 200); }
  } else {
    let lp = 0;
    for (let i = 0; i < len; i++) { const t = i / sr, cut = 0.02 + 0.5 * Math.pow(Math.sin(Math.PI * t / 3), 2); lp += cut * (Math.random() * 2 - 1 - lp);
      d[i] = lp * (0.35 + 0.65 * Math.pow(Math.sin(Math.PI * t * 1.5), 2)) * 1.4; }
  }
  return buf;
}
function setBuffer(buf, name, fallback) {
  buffer = buf; sourceName = name; isFallback = fallback;
  revBuffer = ac.createBuffer(buf.numberOfChannels, buf.length, buf.sampleRate);
  for (let c = 0; c < buf.numberOfChannels; c++) { const a = buf.getChannelData(c), r = revBuffer.getChannelData(c); for (let i = 0, n = a.length; i < n; i++) r[i] = a[n - 1 - i]; }
  const N = 1200, a = buf.getChannelData(0), step = a.length / N; peaks = new Float32Array(N * 2);
  for (let i = 0; i < N; i++) { let lo = 1, hi = -1; for (let j = Math.floor(i * step), e = Math.min(a.length, Math.floor((i + 1) * step) + 1); j < e; j++) { const v = a[j]; if (v < lo) lo = v; if (v > hi) hi = v; } peaks[i * 2] = lo; peaks[i * 2 + 1] = hi; }
  for (const id of ['tone', 'noise', 'demo']) $(id).classList.toggle('on', name === { tone: 'Built-in tone', noise: 'Built-in noise', demo: 'Demo sample' }[id]);
  if (playing) startDry();
  say('');
}
const say = t => { $('msg').textContent = t; };
async function loadArrayBuffer(ab, name) {
  try { const buf = await ac.decodeAudioData(ab); if (buf.duration < 0.05) throw new Error('too short'); setBuffer(buf, name, false); }
  catch (e) { say(`Could not read "${name}" as audio. Still using: ${sourceName}`); }
}
const loadFile = f => f.arrayBuffer().then(ab => loadArrayBuffer(ab, f.name));

// ---------- the granular engine ----------
function scheduleGrain(when) {
  const dur = P.size / 1000, rate = Math.pow(2, P.pitch / 12), span = Math.min(dur * rate, buffer.duration);     // seconds of source this grain reads
  const pos = clamp(P.position / 100 + (Math.random() - 0.5) * (P.spray / 100), 0, 1);
  const offset = pos * (buffer.duration - span), rev = Math.random() * 100 < P.reverse;
  const src = ac.createBufferSource(), env = ac.createGain(), pan = ac.createStereoPanner ? ac.createStereoPanner() : null, pv = Math.random() * 1.6 - 0.8;
  src.buffer = rev ? revBuffer : buffer; src.playbackRate.value = rate;
  env.gain.value = 0; env.gain.setValueCurveAtTime(HANN, when, dur);
  src.connect(env); if (pan) { pan.pan.value = pv; env.connect(pan); pan.connect(grainBus); } else env.connect(grainBus);
  src.start(when, rev ? buffer.duration - offset - span : offset, span); src.stop(when + dur + 0.02);
  grains.push({ when, dur, a: offset / buffer.duration, b: (offset + span) / buffer.duration, rev, pan: pv, seed: Math.random() });
  stats.scheduled++; if (rev) stats.reversed++; stats.lastRate = rate; stats.lastDur = dur; stats.lastPos = pos;
}
function pump() {       // look a little ahead and book grains on the audio clock
  while (nextTime < ac.currentTime + 0.12) { scheduleGrain(Math.max(nextTime, ac.currentTime + 0.005)); nextTime += (1 / P.density) * (0.6 + Math.random() * 0.8); }
}
function startDry() { stopDry(); drySrc = ac.createBufferSource(); drySrc.buffer = buffer; drySrc.loop = true; drySrc.connect(dry); drySrc.start(); }
function stopDry() { if (drySrc) { try { drySrc.stop(); } catch (e) {} drySrc.disconnect(); drySrc = null; } }
function applyLevels() {
  const m = P.mix / 100, t = ac.currentTime;
  wet.gain.setTargetAtTime(Math.sin(m * Math.PI / 2), t, 0.02); dry.gain.setTargetAtTime(Math.cos(m * Math.PI / 2) * 0.8, t, 0.02);
  grainBus.gain.setTargetAtTime(0.9 / Math.sqrt(Math.max(1, P.density * P.size / 1000)), t, 0.03);    // more overlap -> quieter grains
}
async function play() {
  if (playing) return; await ac.resume();
  playing = true; nextTime = ac.currentTime + 0.03; applyLevels(); startDry(); pump(); timer = setInterval(pump, 25);
  $('play').textContent = 'Stop'; $('play').classList.add('playing');
}
function stop() {
  if (!playing) return; playing = false; clearInterval(timer); stopDry();
  $('play').textContent = 'Play'; $('play').classList.remove('playing');
}

// ---------- controls ----------
for (const k of Object.keys(P)) {
  const el = $(k), sync = () => { P[k] = +el.value; $('o-' + k).textContent = FMT[k](el.value); applyLevels(); };
  el.addEventListener('input', sync); sync();
}
$('play').onclick = () => (playing ? stop() : play());
$('tone').onclick = () => setBuffer(builtIn('tone'), 'Built-in tone', true);
$('noise').onclick = () => setBuffer(builtIn('noise'), 'Built-in noise', true);
$('demo').onclick = () => fetch('samples/plucks.wav').then(r => { if (!r.ok) throw 0; return r.arrayBuffer(); }).then(ab => loadArrayBuffer(ab, 'Demo sample')).catch(() => say('Demo sample needs the local server (samples/plucks.wav).'));
$('file').onchange = e => { if (e.target.files[0]) loadFile(e.target.files[0]); e.target.value = ''; };
addEventListener('dragover', e => { e.preventDefault(); document.body.classList.add('dragging'); });
addEventListener('dragleave', e => { if (!e.relatedTarget) document.body.classList.remove('dragging'); });
addEventListener('drop', e => { e.preventDefault(); document.body.classList.remove('dragging'); const f = e.dataTransfer.files[0]; if (f) loadFile(f); });
addEventListener('keydown', e => { if (e.code === 'Space' && e.target.tagName !== 'BUTTON') { e.preventDefault(); playing ? stop() : play(); } });

// ---------- picture: waveform + one particle per grain ----------
const cv = $('view'), g = cv.getContext('2d');
let VW = 0, VH = 0, dpr = 1;
function fit() { dpr = Math.min(2, devicePixelRatio || 1); const r = cv.getBoundingClientRect(); VW = r.width; VH = r.height; cv.width = Math.round(VW * dpr); cv.height = Math.round(VH * dpr); }
addEventListener('resize', fit); fit();
const PAD = 40, waveX = u => PAD + u * (VW - PAD * 2);
let dragging = false;
const setPos = e => { const r = cv.getBoundingClientRect(), u = clamp((e.clientX - r.left - PAD) / (VW - PAD * 2), 0, 1); $('position').value = (u * 100).toFixed(1); $('position').dispatchEvent(new Event('input')); };
cv.addEventListener('pointerdown', e => { dragging = true; cv.setPointerCapture(e.pointerId); setPos(e); });
cv.addEventListener('pointermove', e => { if (dragging) setPos(e); });
cv.addEventListener('pointerup', () => { dragging = false; });

const TAIL = 0.35, level = new Float32Array(1024);
let rms = 0, shown = 0, rateShown = 0, lastCount = 0, lastT = 0;
function draw() {
  requestAnimationFrame(draw);
  const now = ac.currentTime;
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.globalCompositeOperation = 'source-over'; g.fillStyle = '#0b0d12'; g.fillRect(0, 0, VW, VH);
  const wy = VH * 0.72, wh = Math.min(90, VH * 0.2);
  // the window grains are picked from
  const p0 = clamp(P.position / 100 - P.spray / 200, 0, 1), p1 = clamp(P.position / 100 + P.spray / 200, 0, 1);
  g.fillStyle = 'rgba(111,240,210,0.07)'; g.fillRect(waveX(p0), wy - wh - 14, Math.max(2, waveX(p1) - waveX(p0)), wh * 2 + 28);
  // waveform
  if (peaks) { const N = peaks.length / 2; g.fillStyle = '#3b465e'; for (let i = 0; i < N; i++) { const x = waveX(i / N), lo = peaks[i * 2], hi = peaks[i * 2 + 1]; g.fillRect(x, wy - hi * wh, Math.max(1, (VW - PAD * 2) / N), Math.max(1, (hi - lo) * wh)); } }
  g.fillStyle = '#6ff0d2'; g.fillRect(waveX(P.position / 100) - 1, wy - wh - 14, 2, wh * 2 + 28);
  // grains
  g.globalCompositeOperation = 'lighter'; shown = 0;
  for (let i = grains.length - 1; i >= 0; i--) {
    const q = grains[i], t = now - q.when;
    if (t < 0) continue;                                   // booked but not sounding yet
    if (t > q.dur + TAIL) { grains.splice(i, 1); continue; }
    shown++;
    const u = Math.min(1, t / q.dur), live = t <= q.dur;
    const amp = live ? 0.5 - 0.5 * Math.cos(2 * Math.PI * u) : 0;          // same fade as the sound
    const glow = live ? 0.25 + 0.75 * amp : 0.45 * (1 - (t - q.dur) / TAIL);
    const read = q.rev ? q.b + (q.a - q.b) * u : q.a + (q.b - q.a) * u;    // where in the recording it is reading
    const k = t / (q.dur + TAIL), rise = 1 - Math.pow(1 - k, 2);
    const x = waveX(read) + q.pan * 26 * rise, y = wy - rise * (60 + q.seed * (wy - 110));
    const col = q.rev ? '255,138,92' : '111,240,210', r = (3 + Math.sqrt(q.dur * 1000) * 0.55) * (0.6 + 0.4 * amp);
    if (live) { g.fillStyle = `rgba(${col},${0.5 * amp})`; g.fillRect(Math.min(waveX(q.a), waveX(q.b)), wy + wh + 18, Math.max(2, Math.abs(waveX(q.b) - waveX(q.a))), 3);
      g.strokeStyle = `rgba(${col},${0.25 * amp})`; g.lineWidth = 1; g.beginPath(); g.moveTo(waveX(read), wy); g.lineTo(x, y); g.stroke(); }
    g.fillStyle = `rgba(${col},${glow * 0.18})`; g.beginPath(); g.arc(x, y, r * 2.6, 0, 6.283); g.fill();
    g.fillStyle = `rgba(${col},${glow})`; g.beginPath(); g.arc(x, y, r, 0, 6.283); g.fill();
  }
  g.globalCompositeOperation = 'source-over';
  // read-outs
  analyser.getFloatTimeDomainData(level); let s = 0; for (let i = 0; i < level.length; i++) s += level[i] * level[i]; rms = Math.sqrt(s / level.length);
  if (now - lastT >= 0.5) { rateShown = (stats.scheduled - lastCount) / (now - lastT); lastCount = stats.scheduled; lastT = now; }
  g.font = '13px ui-monospace, Menlo, monospace'; g.textBaseline = 'top'; g.fillStyle = '#8791a8';
  g.fillText(`source: ${sourceName}${isFallback ? '  (built-in fallback, no file loaded)' : ''}   ${buffer ? buffer.duration.toFixed(2) + ' s' : ''}`, PAD, 14);
  g.fillText(`${playing ? rateShown.toFixed(0) : 0} grains/s   ${shown} on screen   ● forward`, PAD, 34);
  g.fillStyle = '#ff8a5c'; g.fillText('● reversed', PAD + g.measureText(`${playing ? rateShown.toFixed(0) : 0} grains/s   ${shown} on screen   ● forward   `).width, 34);
  g.fillStyle = '#232a3a'; g.fillRect(VW - PAD - 120, 18, 120, 6); g.fillStyle = '#6ff0d2'; g.fillRect(VW - PAD - 120, 18, 120 * clamp(rms * 3, 0, 1), 6);
  if (!playing && !grains.length) { g.fillStyle = '#8791a8'; g.textAlign = 'center'; g.font = '15px system-ui, sans-serif'; g.fillText('Press Play. Drop in any short recording, or use the built-in sound.', VW / 2, VH * 0.3); g.textAlign = 'left'; }
}

setBuffer(builtIn('tone'), 'Built-in tone', true);
requestAnimationFrame(draw);
// debug and automation hooks
window.SYNTH = { ac, out, P, stats, state: () => ({ playing, ctx: ac.state, source: sourceName, fallback: isFallback, duration: buffer.duration, scheduled: stats.scheduled, reversed: stats.reversed,
  lastRate: stats.lastRate, lastDur: stats.lastDur, lastPos: stats.lastPos, onScreen: shown, rms, wet: wet.gain.value, dry: dry.gain.value, msg: $('msg').textContent }) };
})();
