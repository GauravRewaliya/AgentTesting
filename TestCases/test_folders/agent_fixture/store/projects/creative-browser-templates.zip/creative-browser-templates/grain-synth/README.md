# Grain Cloud — granular synth in the browser

Load any short audio file and play it as a granular synth. The sound is chopped into tiny overlapping "grains", and every grain shows up on screen as a glowing dot over the waveform, born when it starts and fading as it ends.

Web Audio API for the sound, Canvas 2D for the picture. No libraries, no build step.

## Run it

Serve the folder from a local web server. Browsers block the demo sample when the page is opened straight from disk.

```bash
python3 -m http.server 8000
```

Then open http://localhost:8000 and press **Play**.

## Sound sources

- **Upload audio**, or drag a file onto the page. Anything your browser can decode works, usually WAV, MP3, M4A, OGG or FLAC.
- **Demo sample**: a short plucked-string phrase in `samples/plucks.wav`.
- **Built-in tone** and **Built-in noise** are made in code, so there's always something to play.

## Controls

| Control | What it does |
|---|---|
| Grain size | Length of each grain, 10–500 ms |
| Position | Where in the file grains are read from. You can also click or drag on the waveform |
| Spray | Random spread around that position |
| Density | Grains per second, 1–120 |
| Pitch | −24 to +24 semitones |
| Reverse chance | Share of grains played backwards |
| Wet / dry | Grain cloud vs the plain file |
| Space | Play / stop |

## What's inside

- `index.html`: the page and controls.
- `synth.js`: the audio engine and the visuals.
- `samples/plucks.wav`: the demo sample.

Grains are scheduled slightly ahead of time on the audio clock, so timing stays tight even if drawing hiccups. Each grain has a smooth fade-in and fade-out envelope to avoid clicks. Reversed grains read from a pre-reversed copy of the file.

`window.SYNTH` exposes the audio context and current state for scripting or testing.

## Make it yours

- Change slider ranges and starting values in `index.html`.
- Change the grain envelope, pitch range or scheduling look-ahead in `synth.js`.
- Swap `samples/plucks.wav` for your own sound (keep the file name, or update it in `synth.js`).

## Notes

- Tested in desktop Chrome. Other modern browsers should work but haven't been checked.
- Very high density with long grains can overload slower machines; turn density down if the sound crackles.
- A browser demo, not an audio plugin. It doesn't run in a DAW.

## License

Free to use, change and share for any purpose, personal or commercial. No credit needed. That includes the demo sample, which was generated in code.
