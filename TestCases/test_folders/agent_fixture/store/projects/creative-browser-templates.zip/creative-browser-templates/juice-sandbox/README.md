# Juice Sandbox — tune how a hit feels

One fighter, one training dummy, and five sliders for the effects that make a hit feel strong: hit-stop, screen shake, particles, flash and colour split. Press a key, feel the hit, move a slider, hit again.

Plain JavaScript and Canvas 2D. No libraries, no build step, no image files: the pixel art is drawn in code.

## Run it

Open `index.html` in a browser.

If your browser blocks local files, serve the folder instead:

```bash
python3 -m http.server 8000
```

Then open http://localhost:8000.

## Controls

| Action | Input |
|---|---|
| Light hit | J or the Light hit button |
| Heavy hit | K or the Heavy hit button |
| Presets: Off, Subtle, Crunchy, Too much | 1 / 2 / 3 / 4 |
| Auto-hit (light, light, heavy, on repeat) | A |
| Extras on/off | E |
| Reset | R |

## The five sliders

Every slider is real: it changes the next hit, and the "Last hit" box shows what was measured.

| Slider | What it does | Heavy hit |
|---|---|---|
| Hit-stop (0–300 ms) | Freezes the whole world on impact, rounded to whole frames | 2× longer |
| Shake (0–12 px) | How far the picture jolts, in game pixels | 2× further |
| Particle count (0–200) | Sparks thrown from the hit point | 2× more |
| Flash (0–100%) | How white the dummy turns, plus a faint wash over the scene | Same strength, held 2× longer |
| Chroma (0–8 px) | Pulls the red and blue images apart sideways | 2× wider |

## Not on a slider

**Extras** (key E) adds a dummy wobble, a sword trail and floating damage numbers. Their strength is fixed. The numbers are only for show: the dummy has no health.

There is no sound.

## URL options

| Option | What it does |
|---|---|
| `?ui=0` | Hide the panel and show only the scene |
| `?big=1` | Show the panel 1.5× larger |
| `?manual=1` | Step mode: time only moves when you call `JUICE.step()` from code |

`window.JUICE` also has `hit('light' or 'heavy')`, `set(slider, value)`, `preset(name)`, `state()` and more for scripting.

## What's inside

- `index.html`: the page and panel.
- `juice.js`: the whole sandbox.

The scene is drawn at 240×135 pixels at a fixed 60 updates per second, then scaled up with hard pixel edges.

## Make it yours

- **Slider ranges and the heavy-hit multipliers** are in the `SLIDERS` list at the top of `juice.js`.
- **Presets** are the `PRESETS` object right below it.
- **Attack timing** (wind-up, hold, recovery) is in `ATK`.
- To reuse an effect in your own game, copy the matching block in `hit()` and the matching drawing code in `render()`.

## Notes

- Tested in desktop Chrome. Other modern browsers should work but haven't been checked.
- No touch controls yet.

## License

Free to use, change and share for any purpose, personal or commercial. No credit needed.
