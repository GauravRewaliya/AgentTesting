// Juice Sandbox: one fighter, one training dummy, five sliders. Plain browser Canvas 2D, no libraries.
// All art is drawn in code (synthetic pixel art). Fixed 60 Hz simulation at 240x135, scaled up with hard pixels.
(() => {
'use strict';
const W = 240, H = 135, PAD = 20, BGO = PAD + 28, BW = W + PAD * 2, BH = H + PAD * 2, FLOOR = 108, STEP_MS = 1000 / 60;
const q = new URLSearchParams(location.search);
const MANUAL = q.has('manual');                 // step mode: frames advance only through JUICE.step() (automated tests, frame-by-frame rendering)
if (q.get('ui') === '0') document.body.classList.add('noui');
if (q.has('big')) document.body.classList.add('big');
const $ = id => document.getElementById(id);

// ---------- seeded random (two streams, so shake never changes where sparks go) ----------
const rng = seed => () => { seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
let rnd = rng(1), rndShake = rng(2);
const rr = (a, b) => a + rnd() * (b - a);
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, u) => a + (b - a) * u;
const easeOut = u => 1 - Math.pow(1 - clamp(u, 0, 1), 3);
const easeIO = u => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };

// ---------- the five sliders. "heavy" = what a heavy hit multiplies the slider by ----------
const frames = ms => (ms > 0 ? Math.max(1, Math.round(ms / STEP_MS)) : 0);     // hit-stop is whole frames at 60 per second
const SLIDERS = [
  { key: 'hitstop', label: 'Hit-stop', min: 0, max: 300, step: 10, heavy: 2, show: v => v + ' ms', what: 'freezes the whole world', sub: v => `${v} ms (${frames(v)} fr)` },
  { key: 'shake', label: 'Shake', min: 0, max: 12, step: 1, heavy: 2, show: v => v + ' px', what: 'jolts the picture', sub: v => v + ' px' },
  { key: 'particles', label: 'Particle count', min: 0, max: 200, step: 1, heavy: 2, show: v => String(v), what: 'sparks per hit', sub: v => String(v) },
  { key: 'flash', label: 'Flash', min: 0, max: 100, step: 5, heavy: 1, show: v => v + '%', what: 'dummy turns white', sub: v => v + '%', heavyNote: ', held 2× longer' },
  { key: 'chroma', label: 'Chroma', min: 0, max: 8, step: 1, heavy: 2, show: v => v + ' px', what: 'red/blue colour split', sub: v => v + ' px' },
];
const SL = Object.fromEntries(SLIDERS.map(s => [s.key, s]));
const PRESETS = { Off: [0, 0, 0, 0, 0], Subtle: [30, 1, 8, 40, 0], Crunchy: [80, 4, 28, 80, 1], 'Too much': [220, 12, 160, 100, 6] };
const P = {};
let extras = true, auto = false;

// ---------- canvases ----------
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; return [c, x]; };
const screen = $('view'); screen.width = W; screen.height = H;
const s = screen.getContext('2d', { willReadFrequently: true }); s.imageSmoothingEnabled = false;
const [buf, b] = mk(BW, BH), [chan, ch] = mk(BW, BH), [bgCv, g] = mk(W + BGO * 2, H + BGO * 2);
const [sprP, sp] = mk(64, 56), [sprD, sd] = mk(40, 56), [sprW, sw] = mk(40, 56);
let S = 4;
function resize() {
  const st = $('stage'); S = Math.max(1, Math.floor(Math.min(st.clientWidth / W, st.clientHeight / H)));
  screen.style.width = W * S + 'px'; screen.style.height = H * S + 'px';
}
addEventListener('resize', resize); resize();

function px(c, x, y, w, h, col) { c.fillStyle = col; c.fillRect(x, y, w, h); }
function line(c, x0, y0, x1, y1, col) {
  c.fillStyle = col; const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) | 0;
  for (let i = 0; i <= n; i++) { const u = n ? i / n : 0; c.fillRect(Math.round(x0 + (x1 - x0) * u), Math.round(y0 + (y1 - y0) * u), 1, 1); }
}

// ---------- the room, painted once (bigger than the view so shake never shows an edge) ----------
(function paintRoom() {
  g.translate(BGO, BGO);
  const X0 = -BGO, X1 = W + BGO, Y0 = -BGO, Y1 = H + BGO, BEAM = '#3d2a22', BEAM_HI = '#573c2f';
  px(g, X0, Y0, X1 - X0, Y1 - Y0, '#171422');
  px(g, X0, 22, X1 - X0, 74, '#2b2742');                                                    // paper screens
  for (let x = X0; x < X1; x += 12) px(g, x, 22, 1, 74, '#211d33');
  for (const y of [40, 58, 76]) px(g, X0, y, X1 - X0, 1, '#211d33');
  for (let dy = -17; dy <= 17; dy++) for (let dx = -17; dx <= 17; dx++) {                   // round night window
    const d = Math.hypot(dx, dy); if (d > 17.3) continue;
    px(g, 120 + dx, 52 + dy, 1, 1, d > 15.3 ? BEAM : dy > 6 ? '#28345c' : '#31406e');
  }
  for (let dy = -5; dy <= 5; dy++) for (let dx = -5; dx <= 5; dx++) if (dx * dx + dy * dy <= 26) px(g, 126 + dx, 46 + dy, 1, 1, dx + dy < -3 ? '#f4f7ff' : '#cfdaf5');
  for (const [x, y] of [[109, 44], [113, 58], [131, 60], [117, 40]]) px(g, x, y, 1, 1, '#aebbe0');
  px(g, 120, 36, 1, 33, BEAM); px(g, 104, 52, 33, 1, BEAM);
  px(g, X0, 16, X1 - X0, 6, BEAM); px(g, X0, 16, X1 - X0, 1, BEAM_HI);                     // top beam and posts
  for (let x = -30; x < X1; x += 60) { px(g, x - 2, 16, 5, 92, BEAM); px(g, x - 2, 22, 1, 86, BEAM_HI); }
  px(g, X0, 96, X1 - X0, 12, '#2a1f26'); px(g, X0, 96, X1 - X0, 1, BEAM);                 // wainscot
  px(g, 194, 28, 16, 2, BEAM); px(g, 196, 30, 12, 42, '#d9cfb4'); px(g, 194, 72, 16, 2, BEAM);  // scroll
  for (const [x, y, w, h] of [[200, 35, 4, 1], [201, 36, 1, 6], [199, 44, 6, 1], [202, 45, 1, 7], [199, 50, 3, 1], [200, 56, 5, 1], [200, 57, 1, 5], [204, 57, 1, 5], [200, 62, 5, 1]]) px(g, x, y, w, h, '#2a1f26');
  for (const y of [56, 66]) { px(g, 4, y, 20, 1, BEAM_HI); px(g, 6, y + 1, 1, 2, BEAM); px(g, 21, y + 1, 1, 2, BEAM); px(g, 2, y - 1, 24, 1, '#8a5a2e'); }   // spare swords on a rack
  px(g, X0, FLOOR, X1 - X0, Y1 - FLOOR, '#6a4a33'); px(g, X0, FLOOR, X1 - X0, 1, '#8a6444');  // floor boards
  const rows = [[FLOOR, 114, 0], [114, 122, 20], [122, 132, 8], [132, Y1, 28]];
  for (const [y0, y1, off] of rows) { px(g, X0, y1, X1 - X0, 1, '#573b28'); for (let x = X0 - 40 + off; x < X1; x += 40) px(g, x, y0 + 1, 1, y1 - y0 - 1, '#573b28'); }
  px(g, X0, 122, X1 - X0, Y1 - 122, 'rgba(0,0,0,0.12)'); px(g, X0, 132, X1 - X0, Y1 - 132, 'rgba(0,0,0,0.14)');
  for (const x of [60, 180]) {                                                              // two paper lanterns and their glow
    px(g, x, 22, 1, 4, '#0c0a14'); px(g, x - 3, 25, 7, 1, BEAM); px(g, x - 4, 26, 9, 11, '#ffb04a'); px(g, x - 4, 26, 2, 11, '#ffd58a');
    px(g, x - 4, 29, 9, 1, '#e08a2a'); px(g, x - 4, 33, 9, 1, '#e08a2a'); px(g, x - 3, 37, 7, 1, BEAM);
    g.globalCompositeOperation = 'lighter';
    let gr = g.createRadialGradient(x, 31, 2, x, 31, 46); gr.addColorStop(0, 'rgba(255,160,60,0.30)'); gr.addColorStop(1, 'rgba(255,160,60,0)'); px(g, x - 46, -15, 92, 92, gr);
    gr = g.createRadialGradient(x, 118, 2, x, 118, 40); gr.addColorStop(0, 'rgba(255,170,80,0.10)'); gr.addColorStop(1, 'rgba(255,170,80,0)'); g.save(); g.translate(0, 118); g.scale(1, 0.3); g.translate(0, -118); px(g, x - 40, 78, 80, 80, gr); g.restore();
    g.globalCompositeOperation = 'source-over';
  }
  const v = g.createRadialGradient(120, 70, 70, 120, 70, 190); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)'); px(g, X0, Y0, X1 - X0, Y1 - Y0, v);
})();

// ---------- state ----------
const WASH = 0.15;                              // the faint white wash over the whole picture is this share of the flash
const GUARD = -1.15;                            // sword angle at rest (0 = pointing right, negative = up)
const ATK = {
  light: { wind: 4, hold: 3, rec: 6, aWind: -2.1, aHit: -0.15, aEnd: 0.65, lean: 2, stance: 2, kick: 0.03, y: 30, dmg: [8, 15] },
  heavy: { wind: 12, hold: 8, rec: 10, aWind: -3.5, aHit: 0, aEnd: 1.0, lean: 4, stance: 3, kick: 0.062, y: 33, dmg: [24, 39] },
};
let stepN, simT, player, dummy, parts, nums, trail, fx, queue, hits, last, autoT, autoN, press, dirty = true;
function reset(seed = 1) {
  rnd = rng(seed); rndShake = rng(seed + 1); stepN = 0; simT = 0;
  player = { x: 104, state: 'idle', f: 0 }; dummy = { x: 136, th: 0, vth: 0 };
  parts = []; nums = []; trail = null; queue = null; hits = 0; last = null; autoT = 20; autoN = 0; press = { light: 0, heavy: 0 };
  fx = { freeze: 0, shakeAmp: 0, shakeT: 0, shakeLen: 1, ox: 0, oy: 0, flash: 0, flashT: 0, flashLen: 1, chroma: 0, chromaT: 0, chromaLen: 1 };
  dirty = true;
}
const flashNow = () => fx.flash * (fx.flashT / fx.flashLen);
const chromaNow = () => Math.round(fx.chroma * (fx.chromaT / fx.chromaLen));
function rollShake(u) {
  const m = fx.shakeAmp * u;
  if (m < 0.5) { fx.ox = fx.oy = 0; return; }
  const a = rndShake() * Math.PI * 2; fx.ox = Math.round(Math.cos(a) * m); fx.oy = Math.round(Math.sin(a) * m);
  if (last) last.peakShake = Math.max(last.peakShake, Math.round(Math.hypot(fx.ox, fx.oy)));
}
function trigger(type) { queue = type; press[type] = 8; }

// ---------- one hit: this is the only place the five sliders are read ----------
function hit(type) {
  const heavy = type === 'heavy', A = ATK[type], amt = k => P[k] * (heavy ? SL[k].heavy : 1);
  const hx = dummy.x - 7, hy = FLOOR - A.y;
  hits++;
  last = { type, askedMs: amt('hitstop'), frozenFrames: frames(amt('hitstop')), frozenMs: null, t0: performance.now(), sparks: Math.round(amt('particles')), shake: amt('shake'), peakShake: 0, flash: P.flash, chroma: amt('chroma'), extras };
  fx.freeze = last.frozenFrames;                                                             // 1 hit-stop
  fx.shakeAmp = amt('shake'); fx.shakeLen = fx.shakeT = heavy ? 22 : 14; rollShake(1);       // 2 shake
  for (let i = 0; i < last.sparks; i++) {                                                    // 3 particles
    const back = rnd() < 0.18, a = back ? rr(2.2, 3.6) : rr(-1.25, 0.45), v = rr(0.5, 3.1) * (heavy ? 1.35 : 1), life = Math.round(rr(14, 40));
    parts.push({ x: hx, y: hy + rr(-3, 3), vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.4, life, max: life, size: rnd() < 0.3 ? 2 : 1 });
  }
  if (parts.length > 4000) parts.splice(0, parts.length - 4000);
  fx.flash = P.flash / 100; fx.flashLen = fx.flashT = heavy ? 12 : 6;                        // 4 flash
  fx.chroma = amt('chroma'); fx.chromaLen = fx.chromaT = heavy ? 18 : 10;                    // 5 chroma
  if (extras) {                                                                              // fixed extras, not on a slider
    dummy.vth += A.kick; trail = { type, t: 0 };
    nums.push({ x: hx - 3 + Math.round(rr(-3, 3)), y: hy - 14, t: 0, text: String(Math.round(rr(A.dmg[0], A.dmg[1]))), heavy });
  }
  dirty = true;
}

function tick() {
  stepN++;
  for (const k in press) if (press[k] > 0 && --press[k] === 0) dirty = true;
  if (auto && --autoT <= 0) { trigger(autoN++ % 3 === 2 ? 'heavy' : 'light'); autoT = 54; dirty = true; }
  if (fx.freeze > 0) { fx.freeze--; rollShake(1); return; }       // hit-stop: nothing moves, only the shake keeps jittering
  if (last && last.frozenMs === null) { last.frozenMs = Math.max(0, performance.now() - last.t0 - (last.frozenFrames ? STEP_MS : 0)); if (!last.frozenFrames) last.frozenMs = 0; dirty = true; }
  simT++;
  if (fx.shakeT > 0) fx.shakeT--; rollShake(fx.shakeT / fx.shakeLen);
  if (fx.flashT > 0) fx.flashT--;
  if (fx.chromaT > 0) fx.chromaT--;
  if (player.state === 'idle') { if (queue) { player.state = queue; player.f = 0; queue = null; } }
  else {
    const A = ATK[player.state]; player.f++;
    if (player.f === A.wind) hit(player.state);
    else if (player.f >= A.wind + 2 + A.hold + A.rec) player.state = 'idle';
    else if (queue && player.f > A.wind + 1) { player.state = queue; player.f = 0; queue = null; }
  }
  dummy.vth += -0.035 * dummy.th - 0.09 * dummy.vth; dummy.th = clamp(dummy.th + dummy.vth, -0.5, 0.5);
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i]; p.vy += 0.13; p.vx *= 0.975; p.x += p.vx; p.y += p.vy;
    if (p.y > FLOOR + 1 && p.vy > 0) { p.y = FLOOR + 1; p.vy *= -0.4; p.vx *= 0.7; }
    if (--p.life <= 0) parts.splice(i, 1);
  }
  for (let i = nums.length - 1; i >= 0; i--) { const n = nums[i]; n.t++; n.y -= n.t < 10 ? 1 : 0.25; if (n.t > 40) nums.splice(i, 1); }
  if (trail && ++trail.t > 5) trail = null;
}

// ---------- sprites (drawn in code every frame) ----------
function pose() {
  const st = player.state, f = player.f;
  if (st === 'idle') return { a: GUARD + Math.sin(simT / 20) * 0.06, lean: 0, crouch: Math.sin(simT / 16) > 0.2 ? 1 : 0, stance: 0 };
  const A = ATK[st];
  if (f < A.wind) { const u = easeOut((f + 1) / A.wind); return { a: lerp(GUARD, A.aWind, u), lean: -Math.round(u * A.lean / 2), crouch: st === 'heavy' ? Math.round(u * 2) : 0, stance: Math.round(u) }; }
  if (f === A.wind) return { a: A.aHit, lean: A.lean, crouch: 1, stance: A.stance };
  if (f <= A.wind + 1 + A.hold) return { a: A.aEnd, lean: A.lean, crouch: 1, stance: A.stance };
  const u = easeIO((f - (A.wind + 1 + A.hold)) / A.rec);
  return { a: lerp(A.aEnd, GUARD, u), lean: Math.round(lerp(A.lean, 0, u)), crouch: u < 0.5 ? 1 : 0, stance: Math.round(lerp(A.stance, 0, u)) };
}
function drawPlayer(c, o) {         // 64x56 scratch canvas, feet at (28, 50), facing right
  const SKIN = '#f2c79a', HAIR = '#2b1d2e', GI = '#e9e4d8', GI_SH = '#b9b2a3', BELT = '#d0343f', PANTS = '#2e3350', SHOE = '#1b1d2e', WOOD = '#9a6232', WOOD_HI = '#e2a765';
  c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, 64, 56); c.translate(8, 6);
  const L = o.lean, y0 = o.crouch, st = o.stance;
  px(c, 14 + L, 24 + y0, 2, 6, GI_SH);                                                      // back arm
  px(c, 16 - st, 35 + y0, 3, 9 - y0, PANTS); px(c, 16 - st, 42, 4, 2, SHOE);                // legs
  px(c, 22 + st, 35 + y0, 3, 9 - y0, PANTS); px(c, 22 + st, 42, 4, 2, SHOE);
  px(c, 15 + L, 21 + y0, 10, 14, GI); px(c, 15 + L, 21 + y0, 2, 14, GI_SH);                 // jacket
  px(c, 21 + L, 21 + y0, 1, 1, GI_SH); px(c, 20 + L, 22 + y0, 1, 2, GI_SH); px(c, 19 + L, 24 + y0, 1, 2, GI_SH);
  px(c, 15 + L, 30 + y0, 10, 2, BELT); px(c, 17 + L, 32 + y0, 1, 3, BELT);
  const hx = 17 + L + (L > 0 ? 1 : 0), hy = 12 + y0;                                        // head
  px(c, hx, hy, 8, 8, SKIN); px(c, hx, hy - 1, 8, 3, HAIR); px(c, hx - 1, hy, 2, 6, HAIR); px(c, hx + 5, hy + 4, 1, 2, '#2a1f26'); px(c, hx, hy + 2, 8, 1, BELT);
  for (let i = 0; i < 6; i++) px(c, hx - 2 - i, hy + 2 + Math.round(Math.sin(simT / 6 + i * 0.9) * 1.3 * (i / 5)) + (i > 3 ? 1 : 0), 1, 1, i % 3 === 2 ? '#9e2630' : BELT);
  const sx = 22 + L, sy = 24 + y0, ca = Math.cos(o.a), sa = Math.sin(o.a), ax = sx + ca * 4, ay = sy + sa * 4;   // sword arm
  line(c, ax - sa, ay + ca, ax + ca * 17 - sa, ay + sa * 17 + ca, WOOD); line(c, ax, ay, ax + ca * 17, ay + sa * 17, WOOD_HI);
  line(c, sx, sy, ax, ay, GI); line(c, sx, sy + 1, ax, ay + 1, GI); px(c, Math.round(ax) - 1, Math.round(ay) - 1, 2, 2, SKIN);
}
(function drawDummy() {             // 40x56, base at (20, 54). Drawn once; the wobble is done when it is copied to the screen
  const WOOD = '#6b4423', WOOD_HI = '#8a5a2e', STRAW = '#d9b866', STRAW_SH = '#a98842', STRAW_HI = '#ecd08a', ROPE = '#6a4a26', SACK = '#e6d9b8', RED = '#c8323c';
  px(sd, 12, 52, 16, 3, WOOD); px(sd, 12, 52, 16, 1, WOOD_HI); px(sd, 17, 49, 6, 3, WOOD);
  px(sd, 18, 34, 4, 16, WOOD); px(sd, 18, 34, 1, 16, WOOD_HI);
  px(sd, 6, 17, 28, 3, WOOD); px(sd, 6, 17, 28, 1, WOOD_HI); px(sd, 6, 16, 2, 5, ROPE); px(sd, 32, 16, 2, 5, ROPE);
  px(sd, 13, 13, 14, 22, STRAW); px(sd, 24, 13, 3, 22, STRAW_SH); px(sd, 13, 13, 1, 22, STRAW_HI);
  for (const [x, y, h] of [[15, 16, 3], [22, 18, 4], [16, 28, 3], [21, 27, 2], [18, 15, 2]]) px(sd, x, y, 1, h, STRAW_SH);
  px(sd, 13, 14, 14, 1, ROPE); px(sd, 13, 31, 14, 1, ROPE); px(sd, 13, 34, 14, 1, STRAW_SH);
  px(sd, 17, 20, 4, 1, RED); px(sd, 16, 21, 1, 4, RED); px(sd, 21, 21, 1, 4, RED); px(sd, 17, 25, 4, 1, RED); px(sd, 18, 22, 2, 2, RED);
  px(sd, 15, 3, 10, 9, SACK); px(sd, 22, 3, 3, 9, '#c9bb97'); px(sd, 16, 2, 8, 1, SACK); px(sd, 16, 11, 8, 2, ROPE);
  px(sd, 17, 6, 2, 2, '#3a2a1a'); px(sd, 21, 6, 2, 2, '#3a2a1a'); for (const x of [17, 19, 21]) px(sd, x, 9, 1, 1, '#3a2a1a');
  sw.drawImage(sprD, 0, 0); sw.globalCompositeOperation = 'source-in'; px(sw, 0, 0, 40, 56, '#ffffff');      // all-white copy for the flash
})();
function blitDummy(img) { for (let r = 0; r < 56; r++) b.drawImage(img, 0, r, 40, 1, dummy.x - 20 + Math.round((54 - r) * dummy.th), FLOOR - 54 + r, 40, 1); }
const DIGITS = ['111101101101111', '010110010010111', '111001111100111', '111001111001111', '101101111001001', '111100111001111', '111100111101111', '111001001001001', '111101111101111', '111101111001111'];
function digits(text, x, y, k, col) {
  for (let pass = 0; pass < 2; pass++) [...text].forEach((d, i) => { const m = DIGITS[+d]; for (let j = 0; j < 15; j++) if (m[j] === '1') px(b, x + i * 4 * k + (j % 3) * k + (pass ? 0 : 1), y + ((j / 3) | 0) * k + (pass ? 0 : 1), k, k, pass ? col : '#1a1020'); });
}
const SPARK = ['#c8323c', '#ff8a2a', '#ffd24a', '#fff6c8'];

function render() {
  const o = pose();
  b.setTransform(1, 0, 0, 1, 0, 0); b.globalAlpha = 1;
  b.translate(PAD + fx.ox, PAD + fx.oy);                                    // shake moves the whole picture
  b.drawImage(bgCv, -BGO, -BGO);
  px(b, player.x - 9, FLOOR, 18, 1, 'rgba(0,0,0,0.35)'); px(b, player.x - 6, FLOOR + 1, 12, 1, 'rgba(0,0,0,0.3)');
  px(b, dummy.x - 10, FLOOR, 20, 1, 'rgba(0,0,0,0.35)'); px(b, dummy.x - 7, FLOOR + 1, 14, 1, 'rgba(0,0,0,0.3)');
  blitDummy(sprD);
  const fl = flashNow();
  if (fl > 0) { b.globalAlpha = fl; blitDummy(sprW); b.globalAlpha = 1; }   // flash: the dummy fades to white
  drawPlayer(sp, o); b.drawImage(sprP, player.x - 28, FLOOR - 50);
  if (trail) {                                                              // sword trail (extra)
    const A = ATK[trail.type], cx = player.x + 2 + o.lean, cy = FLOOR - 20 + o.crouch, a0 = A.aHit - 1.5, a1 = o.a, fade = 1 - trail.t / 6;
    b.fillStyle = '#fff3d0';                                                // a solid crescent, thin and faint at the tail, thick and bright at the blade
    for (let y = -26; y <= 26; y++) for (let x = -26; x <= 26; x++) {
      const r = Math.hypot(x, y), u = (Math.atan2(y, x) - a0) / (a1 - a0 || 1);
      if (u < 0 || u > 1 || r > 25.5 || r < 25.5 - 8 * u) continue;
      b.globalAlpha = (u > 0.66 ? 0.95 : u > 0.33 ? 0.55 : 0.25) * fade; b.fillRect(cx + x, cy + y, 1, 1);
    }
    b.globalAlpha = 1;
  }
  for (const p of parts) px(b, Math.round(p.x), Math.round(p.y), p.size, p.size, SPARK[Math.min(3, (p.life / p.max * 4) | 0)]);
  for (const n of nums) if (n.t < 32 || (n.t >> 1) & 1) digits(n.text, Math.round(n.x), Math.round(n.y), n.heavy ? 2 : 1, n.heavy ? '#ff9a3d' : '#ffe08a');
  b.setTransform(1, 0, 0, 1, 0, 0);
  if (fl > 0) { b.globalAlpha = fl * WASH; px(b, 0, 0, BW, BH, '#ffffff'); b.globalAlpha = 1; }   // and a faint white wash over everything
  // chroma: the red picture slides one way, the blue picture the other, green stays put
  const d = chromaNow();
  s.globalCompositeOperation = 'source-over';
  if (d < 1) s.drawImage(buf, PAD, PAD, W, H, 0, 0, W, H);
  else {
    px(s, 0, 0, W, H, '#000'); s.globalCompositeOperation = 'lighter';
    for (const [col, dir] of [['#ff0000', 1], ['#00ff00', 0], ['#0000ff', -1]]) {
      ch.globalCompositeOperation = 'copy'; ch.drawImage(buf, 0, 0); ch.globalCompositeOperation = 'multiply'; px(ch, 0, 0, BW, BH, col);
      s.drawImage(chan, PAD + dir * d, PAD, W, H, 0, 0, W, H);
    }
    s.globalCompositeOperation = 'source-over';
  }
  if (dirty) { dirty = false; syncUi(); }
}

// ---------- controls ----------
const els = {};
function setSlider(key, v) {
  const c = SL[key]; v = clamp(Math.round(v / c.step) * c.step, c.min, c.max); P[key] = v;
  const e = els[key]; e.input.value = v; e.out.textContent = c.show(v);
  e.sub.textContent = `Light ${c.sub(v)} · heavy ${c.sub(v * c.heavy)}${c.heavyNote || ''}`;
  const now = SLIDERS.map(x => P[x.key]).join();
  for (const bt of $('presets').children) bt.classList.toggle('on', PRESETS[bt.dataset.p].join() === now);
}
function preset(name) { PRESETS[name].forEach((v, i) => setSlider(SLIDERS[i].key, v)); }
function setExtras(v) { extras = !!v; dirty = true; }
function setAuto(v) { auto = !!v; autoT = 1; dirty = true; }
for (const c of SLIDERS) {
  const row = document.createElement('div'); row.className = 'row';
  row.innerHTML = `<label><span>${c.label} <i>${c.what}</i></span><output></output></label><input id="s-${c.key}" type="range" min="${c.min}" max="${c.max}" step="${c.step}"><small></small>`;
  $('sliders').append(row); els[c.key] = { input: row.querySelector('input'), out: row.querySelector('output'), sub: row.querySelector('small') };
  els[c.key].input.addEventListener('input', e => setSlider(c.key, +e.target.value));
}
Object.keys(PRESETS).forEach((name, i) => { const bt = document.createElement('button'); bt.textContent = name; bt.dataset.p = name; bt.title = 'Key ' + (i + 1); bt.onclick = () => preset(name); $('presets').append(bt); });
function syncUi() {
  $('b-light').classList.toggle('on', press.light > 0); $('b-heavy').classList.toggle('on', press.heavy > 0);
  $('b-auto').classList.toggle('on', auto); $('b-extras').classList.toggle('on', extras);
  $('last-h').textContent = last ? `Last hit · #${hits} ${last.type} (measured)` : 'Last hit (measured)';
  if (!last) { $('last').innerHTML = '<span>No hits yet</span><span></span>'; return; }
  const ms = last.frozenMs === null ? '…' : MANUAL ? (last.frozenFrames * STEP_MS).toFixed(0) + ' ms' : last.frozenMs.toFixed(0) + ' ms';
  const rowsOut = [['Frozen for', `${last.frozenFrames} fr · ${ms}`], ['Biggest jolt', last.peakShake + ' px'], ['Sparks made', last.sparks], ['Flash', last.flash + '%'], ['Colour split', last.chroma + ' px']];
  $('last').innerHTML = rowsOut.map(([k, v]) => `<span>${k}</span><span>${v}</span>`).join('');
}
$('b-light').onclick = () => trigger('light'); $('b-heavy').onclick = () => trigger('heavy');
$('b-auto').onclick = () => setAuto(!auto); $('b-extras').onclick = () => setExtras(!extras);
addEventListener('keydown', e => {
  if (e.repeat || e.metaKey || e.ctrlKey || e.altKey) return;
  const n = ['Digit1', 'Digit2', 'Digit3', 'Digit4'].indexOf(e.code);
  if (e.code === 'KeyJ') trigger('light'); else if (e.code === 'KeyK') trigger('heavy');
  else if (n >= 0) preset(Object.keys(PRESETS)[n]);
  else if (e.code === 'KeyA') setAuto(!auto); else if (e.code === 'KeyE') setExtras(!extras);
  else if (e.code === 'KeyR') reset(); else return;
  dirty = true; e.preventDefault();
});

// ---------- run ----------
reset(); preset('Crunchy'); render();
const state = () => ({ step: stepN, simT, player: { state: player.state, f: player.f }, frozen: fx.freeze, shake: { x: fx.ox, y: fx.oy }, flash: +flashNow().toFixed(3), chroma: chromaNow(), sparks: parts.length, numbers: nums.length, trail: !!trail, dummyLean: +dummy.th.toFixed(4), hits, last: last && { ...last }, P: { ...P }, extras, auto, scale: S });
window.JUICE = {
  P, PRESETS, WASH, state, set: setSlider, preset, setExtras, setAuto, hit: trigger,
  step(n = 1) { for (let i = 0; i < n; i++) tick(); render(); return state(); },
  reset(seed) { reset(seed); render(); },
  pixels: (x, y, w, h) => Array.from(s.getImageData(x, y, w, h).data),
};
if (!MANUAL) {
  let lastT = performance.now(), acc = 0;
  const frame = t => {
    acc += Math.min(100, t - lastT); lastT = t;
    let n = 0; while (acc >= STEP_MS && n < 5) { tick(); acc -= STEP_MS; n++; }
    if (n === 5) acc = 0;
    render(); requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
}
})();
