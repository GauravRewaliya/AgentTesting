// Sound World: audio drives a small 3D world. Sound analysis: Web Audio AnalyserNode. Picture: Three.js (WebGL), a 3D scene.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const $ = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
if (params.get('ui') === '0') document.body.classList.add('noui');
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
let seed = 7;
const rnd = () => { seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const rr = (a, b) => a + rnd() * (b - a);

// ================= audio =================
const AC = window.AudioContext || window.webkitAudioContext;
const ac = new AC();
const analyser = ac.createAnalyser(); analyser.fftSize = 4096; analyser.smoothingTimeConstant = 0.78; analyser.minDecibels = -90; analyser.maxDecibels = -18;   // headroom so loud music does not pin every band at full
const beatAn = ac.createAnalyser(); beatAn.fftSize = 1024; beatAn.smoothingTimeConstant = 0;                    // a second, unsmoothed listener just for beats
const beatNow = new Uint8Array(beatAn.frequencyBinCount);
const outGain = ac.createGain(); outGain.connect(ac.destination);            // what you hear (never the mic, to avoid feedback)
const freq = new Uint8Array(analyser.frequencyBinCount), wave = new Float32Array(analyser.fftSize);
let node = null, micStream = null, sourceName = '—', sourceKind = 'none', playing = false, duration = 0;
const say = t => { $('msg').textContent = t; };

function detach() {
  if (node) { try { node.stop && node.stop(); } catch (e) {} node.disconnect(); node = null; }
  if (micStream) { micStream.getTracks().forEach(t => t.stop()); micStream = null; }
}
function useBuffer(buf, name, kind) {
  detach(); node = ac.createBufferSource(); node.buffer = buf; node.loop = true; node.connect(analyser); node.connect(beatAn); node.connect(outGain); node.start();
  sourceName = name; sourceKind = kind; duration = buf.duration; say(''); mark();
}
async function loadArrayBuffer(ab, name) {
  try { const buf = await ac.decodeAudioData(ab); useBuffer(buf, name, 'file'); await setPlaying(true); }
  catch (e) { say(`Could not read "${name}" as audio. Still on: ${sourceName}`); }
}
const loadFile = f => f.arrayBuffer().then(ab => loadArrayBuffer(ab, f.name));
async function useMic() {
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    detach(); micStream = s; node = ac.createMediaStreamSource(s); node.connect(analyser); node.connect(beatAn);         // analysed only, not sent to the speakers
    sourceName = 'Microphone'; sourceKind = 'mic'; duration = 0; say(''); mark(); await setPlaying(true);
  } catch (e) { say('Microphone not available or permission was declined.'); }
}
async function setPlaying(on) {
  if (on) { await ac.resume(); playing = ac.state === 'running'; if (!playing) say('Press Play to start the sound.'); }
  else { await ac.suspend(); playing = false; }
  $('play').textContent = playing ? 'Pause' : 'Play';
}
const mark = () => { $('demo').classList.toggle('on', sourceKind === 'demo'); $('mic').classList.toggle('on', sourceKind === 'mic'); };

// A built-in demo beat, written in code and rendered once (16 s loop, 120 BPM), so there is always something to play.
let demoBuf = null;
async function demoBeat() {
  if (demoBuf) return demoBuf;
  const sr = 44100, B = 0.5, len = 32 * B, oc = new OfflineAudioContext(2, sr * len, sr), master = oc.createGain(), comp = oc.createDynamicsCompressor();
  master.gain.value = 0.85; master.connect(comp); comp.connect(oc.destination);
  const nb = oc.createBuffer(1, sr, sr), nd = nb.getChannelData(0); for (let i = 0; i < sr; i++) nd[i] = rnd() * 2 - 1;
  const env = (g, t, peak, d, a = 0.004) => { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d); };
  const tone = (t, type, f0, f1, peak, d, glide = 0.1, cutoff = 0) => { const o = oc.createOscillator(), g = oc.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + glide); env(g, t, peak, d);
    if (cutoff) { const f = oc.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = cutoff; o.connect(f); f.connect(g); } else o.connect(g); g.connect(master); o.start(t); o.stop(t + d + 0.1); };
  const noise = (t, type, fq, peak, d, q = 1) => { const s = oc.createBufferSource(), f = oc.createBiquadFilter(), g = oc.createGain(); s.buffer = nb; f.type = type; f.frequency.value = fq; f.Q.value = q; env(g, t, peak, d, 0.002); s.connect(f); f.connect(g); g.connect(master); s.start(t); s.stop(t + d + 0.05); };
  const roots = [55, 43.65, 65.41, 49], chords = [[220, 261.63, 329.63, 440], [174.61, 220, 261.63, 349.23], [196, 261.63, 329.63, 392], [196, 246.94, 293.66, 392]];
  for (let bar = 0; bar < 8; bar++) for (let q = 0; q < 4; q++) {
    const t = (bar * 4 + q) * B, c = bar % 4;
    tone(t, 'sine', 150, 45, 1, 0.3, 0.11);                                             // kick
    tone(t + B / 2, 'sawtooth', roots[c] * 2, roots[c] * 2, 0.3, 0.2, 0.1, 420);          // off-beat bass
    if (bar >= 2) { noise(t + B / 2, 'highpass', 7500, 0.5, 0.06); if (bar >= 6) noise(t + B / 4, 'highpass', 9000, 0.25, 0.035), noise(t + (3 * B) / 4, 'highpass', 9000, 0.25, 0.035); }
    if (bar >= 4 && q % 2 === 1) noise(t, 'bandpass', 1800, 0.5, 0.16, 0.8);              // clap
    if (bar >= 4) for (let k = 0; k < 2; k++) tone(t + (k * B) / 2, 'triangle', chords[c][(q * 2 + k) % 4] * 2, chords[c][(q * 2 + k) % 4] * 2, 0.16, 0.2);   // arpeggio
    if (bar >= 2 && q === 0) for (const f of chords[c]) { const o = oc.createOscillator(), g = oc.createGain(); o.type = 'triangle'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.045, t + 0.4); g.gain.linearRampToValueAtTime(0.0001, t + 4 * B); o.connect(g); g.connect(master); o.start(t); o.stop(t + 4 * B + 0.05); }
  }
  demoBuf = await oc.startRendering(); return demoBuf;
}

// ---- analysis: loudness + three bands + 48-band spectrum + beat pulse, all scaled by Sensitivity ----
const L = { amp: 0, bass: 0, mid: 0, treble: 0 }, raw = { amp: 0, bass: 0, mid: 0, treble: 0 };
const NB = 48, spec = new Float32Array(NB), edges = Array.from({ length: NB + 1 }, (_, i) => 40 * Math.pow(12000 / 40, i / NB));
let sens = 1, fluxPeak = 0, sinceBeat = 9, beats = 0, kick = 0;
const eHist = [0, 0, 0, 0, 0];
const curve = x => Math.pow(Math.max(0, (x - 0.18) / 0.82), 1.3);     // ignore the quiet floor, keep contrast
const follow = (k, target) => { L[k] += (target - L[k]) * (target > L[k] ? 0.5 : 0.12); };
function analyse(dt) {
  let isBeat = false;
  if (playing && node) {
    analyser.getByteFrequencyData(freq); analyser.getFloatTimeDomainData(wave);
    let s = 0; for (let i = 0; i < wave.length; i++) s += wave[i] * wave[i];
    const hz = ac.sampleRate / analyser.fftSize, bin = f => clamp(Math.round(f / hz), 1, freq.length - 1);
    const band = (lo, hi) => { let a = 0, n = 0, m = 0; for (let i = bin(lo); i <= bin(hi); i++) { a += freq[i]; n++; if (freq[i] > m) m = freq[i]; } return curve((a / n + m) / 510); };   // half average, half peak, so a single strong note still counts
    raw.amp = Math.sqrt(s / wave.length); raw.bass = band(30, 140); raw.mid = band(300, 2000); raw.treble = band(4000, 12000);
    for (let i = 0; i < NB; i++) { let m = 0; for (let b = bin(edges[i]), e = Math.max(b, bin(edges[i + 1])); b <= e; b++) if (freq[b] > m) m = freq[b];
      const v = Math.min(1.4, curve(m / 255) * (0.8 + (i / NB) * 0.7) * sens); spec[i] += (v - spec[i]) * (v > spec[i] ? 0.6 : 0.18); }
    // beat = a sudden jump in low-end energy (40-190 Hz), judged against the recent strongest jump
    beatAn.getByteFrequencyData(beatNow); let e = 0; for (let i = 1; i <= 4; i++) e += beatNow[i]; e = (e / 4 / 255) * sens;
    const flux = e - Math.min(...eHist); eHist.push(e); eHist.shift();          // how far the low end jumped compared with the last few frames
    fluxPeak = Math.max(fluxPeak * 0.997, flux); sinceBeat += dt;
    if (flux > fluxPeak * 0.55 && flux > 0.08 && sinceBeat > 0.3) { isBeat = true; sinceBeat = 0; beats++; }
  } else { raw.amp = raw.bass = raw.mid = raw.treble = 0; for (let i = 0; i < NB; i++) spec[i] *= 0.9; }
  follow('amp', Math.min(1.5, raw.amp * 3 * sens)); follow('bass', Math.min(1.5, raw.bass * 1.1 * sens)); follow('mid', Math.min(1.5, raw.mid * 2 * sens)); follow('treble', Math.min(1.5, raw.treble * 3.5 * sens));
  return isBeat;
}

// ================= the 3D world =================
const PALETTES = {
  Aurora: { bg: 0x050814, a: 0x38f5c8, b: 0x6a7dff, c: 0xd16bff },
  Ember: { bg: 0x120606, a: 0xffc857, b: 0xff5e3a, c: 0xc81d5e },
  Neon: { bg: 0x07020f, a: 0x00f0ff, b: 0xff2bd6, c: 0xf9f871 },
  Mono: { bg: 0x08090b, a: 0xffffff, b: 0x9aa3b2, c: 0x4d5564 },
};
let paletteName = 'Aurora';
const renderer = new THREE.WebGLRenderer({ canvas: $('view'), antialias: true });
renderer.setPixelRatio(params.has('pr1') ? 1 : Math.min(devicePixelRatio, 2)); renderer.setSize(innerWidth, innerHeight);
const scene = new THREE.Scene(); scene.fog = new THREE.FogExp2(0x050814, 0.026);
const camera = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 400); camera.position.set(0, 7, 19);
const controls = new OrbitControls(camera, renderer.domElement); controls.target.set(0, 2.2, 0); controls.enableDamping = true; controls.autoRotate = true; controls.autoRotateSpeed = 0.7; controls.minDistance = 6; controls.maxDistance = 40; controls.maxPolarAngle = Math.PI * 0.495;
function blob() { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.3, 'rgba(255,255,255,0.5)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); }
const GLOW = blob(), cA = new THREE.Color(), cB = new THREE.Color(), cC = new THREE.Color(), tmp = new THREE.Color();
const grad = (u, out) => (u < 0.5 ? out.copy(cA).lerp(cB, u * 2) : out.copy(cB).lerp(cC, u * 2 - 2 + 1));

// ground grid: bass makes it swell, each beat sends a ripple outward
const groundGeo = new THREE.PlaneGeometry(80, 80, 96, 96).rotateX(-Math.PI / 2);
const ground = new THREE.Mesh(groundGeo, new THREE.MeshBasicMaterial({ wireframe: true, transparent: true, opacity: 0.32 })); scene.add(ground);
const gp = groundGeo.attributes.position, gR = new Float32Array(gp.count); for (let i = 0; i < gp.count; i++) gR[i] = Math.hypot(gp.getX(i), gp.getZ(i));
const ripples = [];
// spectrum ring: 96 pillars (48 bands, mirrored)
const NP = 96, pillars = new THREE.InstancedMesh(new THREE.BoxGeometry(0.3, 1, 0.3).translate(0, 0.5, 0), new THREE.MeshBasicMaterial(), NP), dummy = new THREE.Object3D(); scene.add(pillars);
pillars.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(NP * 3), 3);
// the orb: loudness scales it, the spectrum bends its surface
const orbGeo = new THREE.IcosahedronGeometry(1, 5), orbBase = orbGeo.attributes.position.array.slice();
const orb = new THREE.Mesh(orbGeo, new THREE.MeshBasicMaterial({ wireframe: true, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false })); orb.position.y = 3.2; scene.add(orb);
const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.9, 2), new THREE.MeshBasicMaterial({ color: 0x000000 })); core.position.y = 3.2; scene.add(core);
const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshBasicMaterial({ wireframe: true, transparent: true, opacity: 0.3 })); shell.position.y = 3.2; scene.add(shell);
const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: GLOW, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true })); halo.position.y = 3.2; scene.add(halo);
// particle field: mids spin it, bass lifts it, treble makes it sparkle, beats push it outward
const NPART = 7000, pGeo = new THREE.BufferGeometry(), pPos = new Float32Array(NPART * 3), pCol = new Float32Array(NPART * 3), P = [];
for (let i = 0; i < NPART; i++) { const r = 2.6 + Math.pow(rnd(), 1.6) * 17; P.push({ r, th: rnd() * Math.PI * 2, h: (rnd() + rnd() + rnd() - 1.5) * (0.5 + r * 0.09), sp: rr(0.6, 1.4), ph: rnd() * 6.28 }); }
pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3)); pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
const points = new THREE.Points(pGeo, new THREE.PointsMaterial({ size: 0.1, map: GLOW, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })); points.frustumCulled = false; scene.add(points);
// beat rings + stars
const rings = Array.from({ length: 5 }, () => { const m = new THREE.Mesh(new THREE.RingGeometry(0.94, 1, 128).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); m.position.y = 0.06; m.userData.age = 9; scene.add(m); return m; });
{ const n = 500, pos = new Float32Array(n * 3); for (let i = 0; i < n; i++) { const a = rnd() * 6.28, h = rr(0.05, 1), r = Math.sqrt(1 - h * h); pos.set([Math.cos(a) * r * 200, h * 200, Math.sin(a) * r * 200], i * 3); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); scene.add(new THREE.Points(g, new THREE.PointsMaterial({ size: 2.2, map: GLOW, transparent: true, depthWrite: false, fog: false, opacity: 0.7 }))); }

function setPalette(name) {
  paletteName = name; const p = PALETTES[name]; cA.setHex(p.a); cB.setHex(p.b); cC.setHex(p.c);
  scene.background = new THREE.Color(p.bg); scene.fog.color.setHex(p.bg);
  ground.material.color.copy(cB); orb.material.color.copy(cA); shell.material.color.copy(cC); halo.material.color.copy(cA);
  rings.forEach(r => r.material.color.copy(cA));
  for (let i = 0; i < NPART; i++) { grad((P[i].r - 2.6) / 17, tmp); pCol.set([tmp.r, tmp.g, tmp.b], i * 3); } pGeo.attributes.color.needsUpdate = true;
  document.documentElement.style.setProperty('--a', '#' + cA.getHexString());
  document.querySelectorAll('#palettes button').forEach(b => b.classList.toggle('on', b.textContent === name));
}

const V = { orbScale: 1, ringMax: 0, ringPeak: 0, spin: 0, pointSize: 0, groundMax: 0 };       // what the picture is doing, for the checks
let clockT = 0;
function world(dt, isBeat) {
  clockT += dt; kick *= Math.exp(-dt * 6);
  if (isBeat) { kick = 1; ripples.push({ age: 0, s: 0.6 + L.bass }); if (ripples.length > 5) ripples.shift(); const r = rings.reduce((a, b) => (a.userData.age > b.userData.age ? a : b)); r.userData.age = 0; }
  // ground
  for (const r of ripples) r.age += dt; let gmax = 0;
  for (let i = 0; i < gp.count; i++) { const x = gp.getX(i), z = gp.getZ(i), d = gR[i]; let y = L.bass * 0.7 * Math.sin(x * 0.28 + clockT * 1.3) * Math.cos(z * 0.28 + clockT) * Math.min(1, d / 8);
    for (const r of ripples) { const k = d - r.age * 11; y += r.s * 1.5 * Math.exp(-r.age * 1.1) * Math.exp(-(k * k) / 5); } gp.setY(i, y); if (y > gmax) gmax = y; }
  gp.needsUpdate = true; V.groundMax = gmax;
  // spectrum ring
  let hmax = 0, hpeak = 0;
  for (let i = 0; i < NP; i++) { const b = i < NB ? i : NP - 1 - i, h = spec[b], a = (i / NP) * Math.PI * 2; if (h > hmax) { hmax = h; hpeak = b; }
    dummy.position.set(Math.sin(a) * 9.5, 0, Math.cos(a) * 9.5); dummy.rotation.y = a; dummy.scale.set(1, 0.08 + h * 4.2, 1); dummy.updateMatrix(); pillars.setMatrixAt(i, dummy.matrix);
    grad(b / (NB - 1), tmp).multiplyScalar(0.3 + 0.9 * Math.min(1, h)); pillars.setColorAt(i, tmp); }
  pillars.instanceMatrix.needsUpdate = true; pillars.instanceColor.needsUpdate = true; V.ringMax = 0.08 + hmax * 4.2; V.ringPeak = hpeak;
  // orb
  const op = orbGeo.attributes.position, s0 = 1.3 * (1 + L.amp * 0.8 + kick * 0.12);
  for (let i = 0; i < op.count; i++) { const x = orbBase[i * 3], y = orbBase[i * 3 + 1], z = orbBase[i * 3 + 2], k = 1 + spec[Math.min(NB - 1, ((y * 0.5 + 0.5) * NB) | 0)] * 0.55; op.setXYZ(i, x * k, y * k, z * k); }
  op.needsUpdate = true; orb.scale.setScalar(s0); orb.rotation.y += dt * (0.2 + L.mid); core.scale.setScalar(s0 * 0.98); V.orbScale = s0 / 1.3;
  shell.scale.setScalar(2.3 + L.treble * 1.6); shell.rotation.x += dt * 0.15; shell.rotation.y -= dt * (0.1 + L.treble); shell.material.opacity = 0.18 + L.treble * 0.5;
  halo.scale.setScalar(5 + L.amp * 9); halo.material.opacity = 0.25 + L.amp * 0.5;
  // particles
  V.spin = 0.06 + L.mid * 1.5; V.pointSize = 0.15 * (1 + L.treble * 2.2 + kick * 0.5);
  for (let i = 0; i < NPART; i++) { const q = P[i]; q.th += dt * V.spin * q.sp / (0.35 + q.r * 0.11); const r = q.r * (1 + kick * 0.16 + L.amp * 0.08);
    pPos[i * 3] = Math.sin(q.th) * r; pPos[i * 3 + 1] = 3.2 + q.h * (1 + L.bass * 1.3) + Math.sin(q.th * 2 + q.ph) * 0.35 * (1 + L.bass * 2.5); pPos[i * 3 + 2] = Math.cos(q.th) * r; }
  pGeo.attributes.position.needsUpdate = true; points.material.size = V.pointSize; points.material.opacity = 0.7 + Math.min(0.3, L.treble * 0.5);
  for (const r of rings) { r.userData.age += dt; const a = r.userData.age; r.scale.setScalar(1 + a * 16); r.material.opacity = Math.max(0, 0.9 - a * 0.8); }
  camera.fov = 50 - kick * 2.2; camera.updateProjectionMatrix();
}

// ================= controls + loop =================
for (const name of Object.keys(PALETTES)) { const b = document.createElement('button'); b.textContent = name; b.onclick = () => setPalette(name); $('palettes').appendChild(b); }
setPalette('Aurora');
$('sens').addEventListener('input', () => { sens = +$('sens').value; $('o-sens').textContent = sens.toFixed(1) + '×'; });
$('play').onclick = async () => { if (!node) useBuffer(await demoBeat(), 'Demo beat (built in)', 'demo'); setPlaying(!playing); };
$('demo').onclick = async () => { useBuffer(await demoBeat(), 'Demo beat (built in)', 'demo'); setPlaying(true); };
$('mic').onclick = useMic;
$('orbit').onclick = () => { controls.autoRotate = !controls.autoRotate; $('orbit').classList.toggle('on', controls.autoRotate); };
$('file').onchange = e => { if (e.target.files[0]) loadFile(e.target.files[0]); e.target.value = ''; };
addEventListener('dragover', e => { e.preventDefault(); document.body.classList.add('dragging'); });
addEventListener('dragleave', e => { if (!e.relatedTarget) document.body.classList.remove('dragging'); });
addEventListener('drop', e => { e.preventDefault(); document.body.classList.remove('dragging'); const f = e.dataTransfer.files[0]; if (f) loadFile(f); });
addEventListener('keydown', e => { if (e.code === 'Space' && e.target.tagName !== 'BUTTON') { e.preventDefault(); $('play').click(); } });
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
$('tech').textContent = `3D scene · Three.js r${THREE.REVISION} + Web Audio AnalyserNode`;

let last = performance.now(), frames = 0, fps = 0, fpsT = last;
renderer.setAnimationLoop(() => {
  const now = performance.now(), dt = Math.min(0.05, (now - last) / 1000); last = now;
  const isBeat = analyse(dt); world(dt, isBeat); controls.update(); renderer.render(scene, camera);
  for (const k of ['amp', 'bass', 'mid', 'treble']) $('m-' + k).style.width = clamp(L[k] * 100, 0, 100) + '%';
  $('beat').style.background = kick > 0.5 ? 'var(--a)' : '#1b2140';
  $('src').firstChild.textContent = `Source: ${sourceName} `;
  frames++; if (now - fpsT >= 1000) { fps = (frames * 1000) / (now - fpsT); frames = 0; fpsT = now; }
});

// debug and automation hooks
window.VIZ = { ac, tap: outGain, canvas: renderer.domElement,
  state: () => ({ source: sourceName, kind: sourceKind, playing, ctx: ac.state, micToSpeakers: false, sens, palette: paletteName, beats, fps: +fps.toFixed(1),
    amp: +L.amp.toFixed(3), bass: +L.bass.toFixed(3), mid: +L.mid.toFixed(3), treble: +L.treble.toFixed(3), rawBass: +raw.bass.toFixed(3),
    orbScale: +V.orbScale.toFixed(3), ringTallest: +V.ringMax.toFixed(2), ringPeakBand: V.ringPeak, particleSpin: +V.spin.toFixed(3), particleSize: +V.pointSize.toFixed(3), groundMax: +V.groundMax.toFixed(3), kick: +kick.toFixed(2),
    colors: { bg: scene.background.getHexString(), orb: orb.material.color.getHexString(), ground: ground.material.color.getHexString() }, msg: $('msg').textContent }) };
