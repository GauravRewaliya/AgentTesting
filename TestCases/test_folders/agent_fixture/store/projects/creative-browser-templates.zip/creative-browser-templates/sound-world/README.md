# Sound World — a 3D world that reacts to sound

Play a recording, a built-in beat, or your microphone, and a glowing 3D world moves with it. Bass swells the ground, mids spin the particle field, high notes make it sparkle, and every beat sends out a ripple.

Three.js (WebGL) for the 3D scene, the Web Audio API's AnalyserNode for listening. No build step.

## Run it

Serve the folder from a local web server. The page uses JavaScript modules, and the microphone only works on `localhost` or HTTPS.

```bash
python3 -m http.server 8000
```

Then open http://localhost:8000 and press **Demo beat**.

## Sound sources

- **Load recording**, or drag an audio file onto the page.
- **Demo beat**: a 16-second, 120 BPM loop made in code.
- **Use mic**: asks for permission first. The mic is only listened to, never played back, so there's no feedback.

## What drives what

| Sound | What it moves |
|---|---|
| Loudness | Size and glow of the central orb |
| Bass | Ground swell and particles lifting |
| Mids | Particle field spin speed |
| Treble | Particle size, sparkle and the orb's outer shell |
| Full spectrum | A ring of 96 pillars, low notes to high |
| Beats | A ground ripple, an expanding ring and a particle push |

## Controls

| Control | What it does |
|---|---|
| Sensitivity | Scales every reaction, 0.2× to 3× |
| Palette | Aurora, Ember, Neon or Mono |
| Auto-orbit | Slowly circles the camera |
| Play / Pause, Space | Pause the sound and let the world settle |
| Drag / scroll | Orbit and zoom |

The panel shows live meters for loudness, bass, mids and treble, plus a dot that flashes on each beat.

## URL options

| Option | What it does |
|---|---|
| `?ui=0` | Hide all on-screen controls |
| `?pr1=1` | Render at 1× pixel ratio (faster on high-resolution screens) |

`window.VIZ.state()` returns the live levels and scene values for scripting or testing.

## What's inside

- `index.html`: the page and controls.
- `viz.js`: audio analysis, beat detection and the 3D world.
- `vendor/`: a local copy of Three.js (r187) and its OrbitControls.

## Make it yours

- **Frequency bands** (bass 30–140 Hz, mids 300–2,000 Hz, treble 4–12 kHz) are set in `viz.js`.
- **Palettes** are a small object in `viz.js`. Add your own colour sets there.
- **Beat detection** listens for sudden jumps in low-end energy; its threshold and minimum gap between beats are next to it.

## Notes

- Tested in desktop Chrome. Other modern browsers should work but haven't been checked.
- Beat detection is tuned for music with a clear kick drum. Quiet or beatless audio still moves the world but may not trigger beats.
- Microphones differ a lot in level. Use Sensitivity to match yours.

## License

The project code is free to use, change and share for any purpose, personal or commercial. No credit needed.

Three.js is © the three.js authors and released under the MIT License. Keep `vendor/LICENSE-three.txt` with it.
