import { playlists, type Playlist } from '../data';
import { player, useCurrentTrack, usePlayer } from '../player';
import { href, navigate } from '../router';
import { Cover, PlayButton } from './common';

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}

function usePlayToggle(p: Playlist) {
  const { isPlaying } = usePlayer();
  const current = useCurrentTrack();
  const here = current?.playlistId === p.id;
  return {
    playing: here && isPlaying,
    toggle: () => (here ? player.togglePlay() : player.playContext(p.id)),
  };
}

function QuickTile({ p }: { p: Playlist }) {
  const { playing, toggle } = usePlayToggle(p);
  return (
    <a className="quick-tile" href={href({ name: 'playlist', id: p.id })}>
      <Cover playlist={p} size={64} />
      <span className="quick-name">{p.name}</span>
      <span className="quick-play"><PlayButton playing={playing} onClick={toggle} size={36} label={`Play ${p.name}`} /></span>
    </a>
  );
}

function Card({ p }: { p: Playlist }) {
  const { playing, toggle } = usePlayToggle(p);
  return (
    <div className="card" role="link" tabIndex={0} onClick={() => navigate({ name: 'playlist', id: p.id })}
      onKeyDown={(e) => e.key === 'Enter' && navigate({ name: 'playlist', id: p.id })} data-testid={`card-${p.id}`}>
      <div className="card-art">
        <Cover playlist={p} size={180} />
        <span className="card-play"><PlayButton playing={playing} onClick={toggle} label={`Play ${p.name}`} /></span>
      </div>
      <div className="card-title">{p.name}</div>
      <div className="card-sub">{p.description}</div>
    </div>
  );
}

export function Home() {
  return (
    <div className="page home">
      <div className="page-tint" />
      <h1 className="home-title">{greeting()}</h1>
      <div className="quick-grid">{playlists.slice(0, 6).map((p) => <QuickTile key={p.id} p={p} />)}</div>
      <h2 className="shelf-title">Made for you</h2>
      <div className="card-grid">{playlists.map((p) => <Card key={p.id} p={p} />)}</div>
      <h2 className="shelf-title">Jump back in</h2>
      <div className="card-grid">{[...playlists].reverse().slice(0, 4).map((p) => <Card key={p.id} p={p} />)}</div>
    </div>
  );
}
