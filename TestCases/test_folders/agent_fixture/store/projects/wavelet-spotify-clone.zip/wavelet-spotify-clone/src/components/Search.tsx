import { Search as SearchIcon, X } from 'lucide-react';
import { useEffect, useMemo, useRef } from 'react';
import { playlists, tracks } from '../data';
import { navigate } from '../router';
import { Cover } from './common';
import { TrackTable } from './TrackTable';

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

export function Search({ query }: { query: string }) {
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => input.current?.focus(), []);
  const q = norm(query.trim());
  const words = q.split(/\s+/).filter(Boolean);
  const results = useMemo(
    () => (words.length ? tracks.filter((t) => words.every((w) => norm(`${t.title} ${t.artist} ${t.album}`).includes(w))) : []),
    [q],
  );
  const lists = useMemo(() => (words.length ? playlists.filter((p) => words.every((w) => norm(p.name).includes(w))) : []), [q]);

  return (
    <div className="page search">
      <div className="search-box">
        <SearchIcon size={20} />
        <input
          ref={input}
          value={query}
          onChange={(e) => navigate({ name: 'search', query: e.target.value }, true)}
          placeholder="What do you want to hear?"
          aria-label="Search tracks"
          data-testid="search-input"
        />
        {query && <button className="icon-btn" aria-label="Clear search" onClick={() => navigate({ name: 'search', query: '' }, true)}><X size={18} /></button>}
      </div>

      {!words.length && (
        <>
          <h2 className="shelf-title">Browse your playlists</h2>
          <div className="browse-grid">
            {playlists.map((p) => (
              <button key={p.id} className="browse-tile" onClick={() => navigate({ name: 'playlist', id: p.id })}>
                <span>{p.name}</span>
                <Cover playlist={p} size={84} />
              </button>
            ))}
          </div>
        </>
      )}

      {!!words.length && (
        <>
          {lists.length > 0 && (
            <div className="chip-row">
              {lists.map((p) => <button key={p.id} className="chip" onClick={() => navigate({ name: 'playlist', id: p.id })}>{p.name}</button>)}
            </div>
          )}
          <h2 className="shelf-title" data-testid="search-count">{results.length} {results.length === 1 ? 'song' : 'songs'}</h2>
          {results.length ? <TrackTable tracks={results} showCover /> : <p className="empty">No songs match “{query}”. Try a title, artist or playlist name.</p>}
        </>
      )}
    </div>
  );
}
