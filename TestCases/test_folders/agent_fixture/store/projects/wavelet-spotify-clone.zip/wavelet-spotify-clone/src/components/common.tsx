import { useRef, type KeyboardEvent, type PointerEvent } from 'react';
import { Pause, Play } from 'lucide-react';
import type { Playlist } from '../data';
import { coverUrl } from '../covers';

export function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
      <rect width="28" height="28" rx="8" fill="var(--accent)" />
      <path d="M5 15c2.2-5 4.4-5 6.6 0s4.4 5 6.6 0 2.9-4 4.8-2" stroke="#16121f" strokeWidth="2.6" fill="none" strokeLinecap="round" />
    </svg>
  );
}

export function Cover({ playlist, size, className = '' }: { playlist: Playlist; size: number; className?: string }) {
  return <img className={`cover ${className}`} src={coverUrl(playlist)} width={size} height={size} alt="" draggable={false} />;
}

export function PlayButton({ playing, onClick, size = 48, label }: { playing: boolean; onClick: () => void; size?: number; label: string }) {
  return (
    <button className="play-btn" style={{ width: size, height: size }} onClick={(e) => { e.stopPropagation(); onClick(); }} aria-label={label}>
      {playing ? <Pause size={size * 0.42} fill="currentColor" /> : <Play size={size * 0.42} fill="currentColor" style={{ marginLeft: size * 0.05 }} />}
    </button>
  );
}

/** Horizontal slider for progress and volume: click, drag, or arrow keys. */
export function Slider({ value, max, onChange, label, testId, step }: {
  value: number; max: number; onChange: (v: number) => void; label: string; testId: string; step: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const fromPointer = (e: PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    onChange(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * max);
  };
  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowUp') onChange(Math.min(max, value + step));
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') onChange(Math.max(0, value - step));
    else return;
    e.preventDefault();
    e.stopPropagation();
  };
  return (
    <div
      ref={ref}
      className="slider"
      role="slider"
      tabIndex={0}
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={Math.round(value * 100) / 100}
      data-testid={testId}
      onKeyDown={onKey}
      onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); fromPointer(e); }}
      onPointerMove={(e) => { if (e.currentTarget.hasPointerCapture(e.pointerId)) fromPointer(e); }}
    >
      <div className="slider-track"><div className="slider-fill" style={{ width: `${pct}%` }} /></div>
      <div className="slider-thumb" style={{ left: `${pct}%` }} />
    </div>
  );
}
