import type { Playlist } from './data';

const SIZE = 320;
const cache = new Map<string, string>();

function rng(seed: number) {
  let s = seed >>> 0 || 1;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32);
}

const hsl = (h: number, s: number, l: number, a = 1) => `hsla(${h % 360}, ${s}%, ${l}%, ${a})`;

/** Draws an original abstract cover and returns it as a PNG data URL. */
export function coverUrl(p: Playlist): string {
  const hit = cache.get(p.id);
  if (hit) return hit;
  const { hue, hue2, style, seed } = p.cover;
  const r = rng(seed);
  const c = document.createElement('canvas');
  c.width = c.height = SIZE;
  const g = c.getContext('2d')!;

  const bg = g.createLinearGradient(0, 0, SIZE, SIZE);
  bg.addColorStop(0, hsl(hue, 78, 52));
  bg.addColorStop(1, hsl(hue2, 70, 34));
  g.fillStyle = bg;
  g.fillRect(0, 0, SIZE, SIZE);

  if (style === 'orbs') {
    for (let i = 0; i < 6; i++) {
      const x = r() * SIZE, y = r() * SIZE, rad = 30 + r() * 90;
      const og = g.createRadialGradient(x, y, 0, x, y, rad);
      og.addColorStop(0, hsl(hue + 20, 90, 72, 0.85));
      og.addColorStop(1, hsl(hue, 80, 50, 0));
      g.fillStyle = og;
      g.beginPath(); g.arc(x, y, rad, 0, Math.PI * 2); g.fill();
    }
  } else if (style === 'stripes') {
    g.save();
    g.translate(SIZE / 2, SIZE / 2); g.rotate(-0.5 + r() * 0.3); g.translate(-SIZE, -SIZE);
    for (let i = 0; i < 14; i++) {
      g.fillStyle = hsl(i % 2 ? hue2 : hue + 15, 70, i % 3 ? 60 : 28, 0.55);
      g.fillRect(i * 46, 0, 18 + r() * 14, SIZE * 3);
    }
    g.restore();
  } else if (style === 'peaks') {
    for (let layer = 0; layer < 4; layer++) {
      g.fillStyle = hsl(hue2 + layer * 8, 55, 26 + layer * 9, 0.9);
      g.beginPath(); g.moveTo(0, SIZE);
      for (let x = 0; x <= SIZE; x += 40) g.lineTo(x, SIZE * (0.45 + layer * 0.12) - r() * 70);
      g.lineTo(SIZE, SIZE); g.closePath(); g.fill();
    }
    g.fillStyle = hsl(hue + 30, 90, 80, 0.9);
    g.beginPath(); g.arc(SIZE * (0.25 + r() * 0.5), SIZE * 0.24, 26, 0, Math.PI * 2); g.fill();
  } else {
    const cx = SIZE * (0.35 + r() * 0.3), cy = SIZE * (0.35 + r() * 0.3);
    for (let i = 9; i > 0; i--) {
      g.strokeStyle = hsl(i % 2 ? hue + 25 : hue2, 75, 30 + i * 5, 0.75);
      g.lineWidth = 10;
      g.beginPath(); g.arc(cx, cy, i * 22, 0, Math.PI * 2); g.stroke();
    }
  }

  const grain = g.createLinearGradient(0, SIZE, SIZE, 0);
  grain.addColorStop(0, 'rgba(0,0,0,0.25)');
  grain.addColorStop(1, 'rgba(255,255,255,0.06)');
  g.fillStyle = grain;
  g.fillRect(0, 0, SIZE, SIZE);

  const url = c.toDataURL('image/png');
  cache.set(p.id, url);
  return url;
}
