export type CoverStyle = 'orbs' | 'stripes' | 'peaks' | 'rings';

export interface Playlist {
  id: string;
  name: string;
  description: string;
  owner: string;
  cover: { hue: number; hue2: number; style: CoverStyle; seed: number };
  trackIds: string[];
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  playlistId: string;
  seconds: number;
  tone: { root: number; bpm: number; seed: number };
}

const PLAYLISTS: Array<Omit<Playlist, 'trackIds'> & { tracks: Array<[string, string]> }> = [
  {
    id: 'p1', name: 'Morning Static', description: 'Warm hiss and slow coffee.', owner: 'You',
    cover: { hue: 18, hue2: 40, style: 'orbs', seed: 11 },
    tracks: [['Kettle Light', 'Juniper Vale'], ['Soft Dial', 'The Paper Owls'], ['First Window', 'Juniper Vale'], ['Toast & Tape', 'Mira Holt'], ['Radio Dust', 'The Paper Owls']],
  },
  {
    id: 'p2', name: 'Neon Commute', description: 'Train lights at 6 pm.', owner: 'You',
    cover: { hue: 196, hue2: 250, style: 'stripes', seed: 23 },
    tracks: [['Platform Nine', 'Glass Arcade'], ['Ticket Loop', 'Ohm District'], ['Overpass', 'Glass Arcade'], ['Signal Blue', 'Kai Mercer'], ['Last Car', 'Ohm District']],
  },
  {
    id: 'p3', name: 'Low Tide', description: 'Slow waves for deep work.', owner: 'You',
    cover: { hue: 160, hue2: 190, style: 'peaks', seed: 37 },
    tracks: [['Shoreline', 'Tidepool'], ['Salt Glass', 'Rowan Isle'], ['Kelp Forest', 'Tidepool'], ['Undertow', 'Lena Brooks'], ['Harbor Bell', 'Rowan Isle']],
  },
  {
    id: 'p4', name: 'Paper Planets', description: 'Bedroom synths and cardboard rockets.', owner: 'You',
    cover: { hue: 272, hue2: 310, style: 'rings', seed: 41 },
    tracks: [['Orbit Craft', 'Moth Radio'], ['Tiny Moon', 'Sunny Arcadia'], ['Glue Stick Galaxy', 'Moth Radio'], ['Comet Fold', 'Pia Starling'], ['Crayon Nebula', 'Sunny Arcadia']],
  },
  {
    id: 'p5', name: 'Afterglow Club', description: 'Late-night grooves, low lights.', owner: 'You',
    cover: { hue: 334, hue2: 8, style: 'orbs', seed: 53 },
    tracks: [['Velvet Rope', 'Night Pilots'], ['Mirror Ball', 'Dora Vance'], ['Exit Sign', 'Night Pilots'], ['Taxi Home', 'Lux Ferro'], ['4 AM Bloom', 'Dora Vance']],
  },
  {
    id: 'p6', name: 'Quiet Machines', description: 'Ambient circuits humming along.', owner: 'You',
    cover: { hue: 222, hue2: 200, style: 'rings', seed: 67 },
    tracks: [['Idle Fan', 'Server Garden'], ['Cold Boot', 'Ada Lin'], ['Sleep Mode', 'Server Garden'], ['Soft Reset', 'Byte Choir'], ['Heat Sink', 'Ada Lin']],
  },
  {
    id: 'p7', name: 'Citrus Drive', description: 'Windows down, sun up.', owner: 'You',
    cover: { hue: 46, hue2: 90, style: 'stripes', seed: 71 },
    tracks: [['Lemon Road', 'Sunset Bureau'], ['Orange Grove', 'Theo Marsh'], ['Highway Zest', 'Sunset Bureau'], ['Pulp Fiction Radio', 'Cleo Sands'], ['Lime Horizon', 'Theo Marsh']],
  },
  {
    id: 'p8', name: 'Night Garden', description: 'Moss, moths and minor keys.', owner: 'You',
    cover: { hue: 108, hue2: 150, style: 'peaks', seed: 83 },
    tracks: [['Fern Lantern', 'Hollow Pines'], ['Moonflower', 'Iris Wren'], ['Dew Line', 'Hollow Pines'], ['Glowworm', 'Ezra Fox'], ['Thorn Lullaby', 'Iris Wren']],
  },
];

const ROOTS = [220, 246.94, 261.63, 196, 293.66, 174.61, 233.08, 207.65];

export const playlists: Playlist[] = [];
export const tracks: Track[] = [];

PLAYLISTS.forEach((p, pi) => {
  const { tracks: list, ...rest } = p;
  const ids: string[] = [];
  list.forEach(([title, artist], ti) => {
    const id = `${p.id}-t${ti + 1}`;
    ids.push(id);
    tracks.push({
      id,
      title,
      artist,
      album: p.name,
      playlistId: p.id,
      seconds: 16 + ((pi * 7 + ti * 5) % 15),
      tone: { root: ROOTS[(pi + ti) % ROOTS.length], bpm: 84 + ((pi * 13 + ti * 9) % 48), seed: p.cover.seed * 10 + ti },
    });
  });
  playlists.push({ ...rest, trackIds: ids });
});

export const trackById = new Map(tracks.map((t) => [t.id, t]));
export const playlistById = new Map(playlists.map((p) => [p.id, p]));

export function formatTime(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
