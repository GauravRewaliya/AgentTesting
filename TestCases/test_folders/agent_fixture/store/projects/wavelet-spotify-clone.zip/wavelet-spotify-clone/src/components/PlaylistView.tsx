import { Shuffle } from 'lucide-react';
import { formatTime, playlistById, trackById } from '../data';
import { player, useCurrentTrack, usePlayer } from '../player';
import { Cover, PlayButton } from './common';
import { TrackTable } from './TrackTable';

export function PlaylistView({ id }: { id: string }) {
  const p = playlistById.get(id);
  const { isPlaying, shuffle } = usePlayer();
  const current = useCurrentTrack();
  if (!p) return <div className="page"><h1>Playlist not found</h1></div>;
  const tracks = p.trackIds.map((t) => trackById.get(t)!);
  const total = tracks.reduce((s, t) => s + t.seconds, 0);
  const here = current?.playlistId === p.id;
  return (
    <div className="page playlist" data-testid="playlist-view" data-playlist={p.id}>
      <div className="page-tint" />
      <header className="pl-header">
        <Cover playlist={p} size={232} className="pl-cover" />
        <div className="pl-info">
          <span className="pl-kind">Playlist</span>
          <h1 className="pl-title">{p.name}</h1>
          <p className="pl-desc">{p.description}</p>
          <p className="pl-meta"><strong>{p.owner}</strong> · {tracks.length} songs, {formatTime(total)}</p>
        </div>
      </header>
      <div className="pl-body">
        <div className="action-bar">
          <PlayButton size={56} playing={here && isPlaying} label={here && isPlaying ? 'Pause' : 'Play'}
            onClick={() => (here ? player.togglePlay() : player.playContext(p.id))} />
          <button className={`icon-btn ${shuffle ? 'on' : ''}`} aria-label="Shuffle" aria-pressed={shuffle} onClick={() => player.setShuffle(!shuffle)}>
            <Shuffle size={26} />
          </button>
        </div>
        <TrackTable tracks={tracks} contextId={p.id} showAlbum={false} />
      </div>
    </div>
  );
}
