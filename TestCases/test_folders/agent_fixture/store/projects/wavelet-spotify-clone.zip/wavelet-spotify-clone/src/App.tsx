import { useEffect, useState, type CSSProperties } from 'react';
import { playlistById } from './data';
import { coverUrl } from './covers';
import { useCoverColor } from './color';
import { player, useCurrentTrack } from './player';
import { useRoute } from './router';
import { Sidebar } from './components/Sidebar';
import { Home } from './components/Home';
import { Search } from './components/Search';
import { PlaylistView } from './components/PlaylistView';
import { NowPlaying } from './components/NowPlaying';
import { PlayerBar } from './components/PlayerBar';

const NEUTRAL = '#2b2a33';

function isTyping(el: EventTarget | null) {
  const t = el as HTMLElement | null;
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
}

export default function App() {
  const route = useRoute();
  const current = useCurrentTrack();
  const [panelOpen, setPanelOpen] = useState(() => window.innerWidth >= 1100);

  const pagePlaylist =
    route.name === 'playlist' ? playlistById.get(route.id)
    : route.name === 'home' && current ? playlistById.get(current.playlistId)
    : undefined;
  const pageColor = useCoverColor(pagePlaylist ? coverUrl(pagePlaylist) : null, NEUTRAL);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'Space' || isTyping(e.target) || e.metaKey || e.ctrlKey || e.altKey) return;
      e.preventDefault();
      player.togglePlay();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className={`app ${panelOpen ? 'with-panel' : ''}`}>
      <Sidebar route={route} />
      <main className="main" data-testid="main-view" style={{ '--page': pageColor } as CSSProperties}>
        <div className="main-scroll">
          {route.name === 'home' && <Home />}
          {route.name === 'search' && <Search query={route.query} />}
          {route.name === 'playlist' && <PlaylistView id={route.id} />}
        </div>
      </main>
      {panelOpen && <NowPlaying onClose={() => setPanelOpen(false)} />}
      <PlayerBar panelOpen={panelOpen} onTogglePanel={() => setPanelOpen((v) => !v)} />
    </div>
  );
}
