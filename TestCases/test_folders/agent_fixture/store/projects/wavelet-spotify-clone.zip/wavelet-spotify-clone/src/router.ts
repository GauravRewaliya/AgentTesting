import { useEffect, useState } from 'react';

export type Route = { name: 'home' } | { name: 'search'; query: string } | { name: 'playlist'; id: string };

export function parse(hash: string): Route {
  const [, page = '', arg = ''] = hash.replace(/^#/, '').split('/');
  if (page === 'search') return { name: 'search', query: decodeURIComponent(arg) };
  if (page === 'playlist' && arg) return { name: 'playlist', id: arg };
  return { name: 'home' };
}

export const href = (r: Route) =>
  r.name === 'home' ? '#/' : r.name === 'search' ? `#/search/${encodeURIComponent(r.query)}` : `#/playlist/${r.id}`;

export function navigate(r: Route, replace = false) {
  const next = href(r);
  if (replace) history.replaceState(null, '', next);
  else location.hash = next;
  if (replace) window.dispatchEvent(new HashChangeEvent('hashchange'));
}

export function useRoute(): Route {
  const [route, setRoute] = useState(() => parse(location.hash));
  useEffect(() => {
    const on = () => setRoute(parse(location.hash));
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return route;
}
