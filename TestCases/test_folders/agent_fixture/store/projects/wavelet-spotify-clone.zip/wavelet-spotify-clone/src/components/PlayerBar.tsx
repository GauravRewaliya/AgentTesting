import { PanelRight, Pause, Play, Repeat, Repeat1, Shuffle, SkipBack, SkipForward, Volume, Volume1, Volume2, VolumeX } from 'lucide-react';
import { formatTime, playlistById } from '../data';
import { player, useCurrentTrack, usePlayer } from '../player';
import { href } from '../router';
import { Cover, Slider } from './common';

export function PlayerBar({ panelOpen, onTogglePanel }: { panelOpen: boolean; onTogglePanel: () => void }) {
  const s = usePlayer();
  const t = useCurrentTrack();
  const p = t ? playlistById.get(t.playlistId) : undefined;
  const vol = s.muted ? 0 : s.volume;
  const VolIcon = vol === 0 ? VolumeX : vol < 0.34 ? Volume : vol < 0.67 ? Volume1 : Volume2;
  const RepeatIcon = s.repeat === 'one' ? Repeat1 : Repeat;

  return (
    <footer className="player-bar" data-testid="player-bar">
      <div className="pb-left" data-testid="now-playing-widget">
        {t && p ? (
          <>
            <a href={href({ name: 'playlist', id: p.id })}><Cover playlist={p} size={56} /></a>
            <div className="pb-text">
              <span className="track-title" data-testid="pb-title">{t.title}</span>
              <span className="track-artist">{t.artist}</span>
            </div>
          </>
        ) : <span className="track-artist">Nothing playing</span>}
      </div>

      <div className="pb-center">
        <div className="pb-controls" data-testid="player-controls">
          <button className={`icon-btn ${s.shuffle ? 'on' : ''}`} aria-label="Shuffle" aria-pressed={s.shuffle} data-testid="control-shuffle"
            onClick={() => player.setShuffle(!s.shuffle)}><Shuffle size={18} /></button>
          <button className="icon-btn" aria-label="Previous" data-testid="control-previous" onClick={() => player.skipToPrevious()}><SkipBack size={20} fill="currentColor" /></button>
          <button className="pb-play" aria-label={s.isPlaying ? 'Pause' : 'Play'} data-testid="control-playpause" onClick={() => player.togglePlay()}>
            {s.isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" style={{ marginLeft: 2 }} />}
          </button>
          <button className="icon-btn" aria-label="Next" data-testid="control-next" onClick={() => player.skipToNext()}><SkipForward size={20} fill="currentColor" /></button>
          <button className={`icon-btn ${s.repeat !== 'off' ? 'on' : ''}`} aria-label={`Repeat: ${s.repeat}`} data-testid="control-repeat" data-repeat={s.repeat}
            onClick={() => player.cycleRepeat()}><RepeatIcon size={18} /></button>
        </div>
        <div className="pb-progress">
          <span className="time" data-testid="playback-position">{formatTime(s.position)}</span>
          <Slider value={s.position} max={s.duration || t?.seconds || 0} step={5} label="Seek" testId="progress-bar" onChange={(v) => player.seekTo(v)} />
          <span className="time" data-testid="playback-duration">{formatTime(s.duration || t?.seconds || 0)}</span>
        </div>
      </div>

      <div className="pb-right">
        <button className={`icon-btn ${panelOpen ? 'on' : ''}`} aria-label="Now playing panel" aria-pressed={panelOpen} onClick={onTogglePanel}><PanelRight size={18} /></button>
        <button className="icon-btn" aria-label={s.muted ? 'Unmute' : 'Mute'} data-testid="control-mute" onClick={() => player.toggleMute()}><VolIcon size={18} /></button>
        <div className="pb-volume"><Slider value={vol} max={1} step={0.1} label="Volume" testId="volume-bar" onChange={(v) => player.setVolume(v)} /></div>
      </div>
    </footer>
  );
}
