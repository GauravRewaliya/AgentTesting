import { Clock3, Pause, Play } from 'lucide-react';
import { formatTime, playlistById, type Track } from '../data';
import { player, useCurrentTrack, usePlayer } from '../player';
import { href } from '../router';
import { Cover } from './common';

export function TrackTable({ tracks, contextId, showAlbum = true, showCover = false }: {
  tracks: Track[]; contextId?: string; showAlbum?: boolean; showCover?: boolean;
}) {
  const { isPlaying } = usePlayer();
  const current = useCurrentTrack();
  return (
    <div className={`track-table ${showAlbum ? '' : 'no-album'}`} role="table" aria-label="Tracks">
      <div className="track-row head" role="row">
        <span>#</span><span>Title</span>{showAlbum && <span>Album</span>}<span className="dur"><Clock3 size={16} /></span>
      </div>
      {tracks.map((t, i) => {
        const active = current?.id === t.id;
        const playHere = () => (active ? player.togglePlay() : player.playContext(contextId ?? t.playlistId, t.id));
        const p = playlistById.get(t.playlistId)!;
        return (
          <div key={t.id} className={`track-row ${active ? 'active' : ''}`} role="row" data-testid={`track-${t.id}`} onDoubleClick={playHere}>
            <span className="num">
              <span className="num-text">{i + 1}</span>
              <button className="row-play" onClick={playHere} aria-label={`${active && isPlaying ? 'Pause' : 'Play'} ${t.title}`}>
                {active && isPlaying ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
              </button>
            </span>
            <span className="title-cell">
              {showCover && <Cover playlist={p} size={40} />}
              <span className="title-text">
                <span className="track-title">{t.title}</span>
                <span className="track-artist">{t.artist}</span>
              </span>
            </span>
            {showAlbum && <a className="track-album" href={href({ name: 'playlist', id: t.playlistId })}>{t.album}</a>}
            <span className="dur">{formatTime(t.seconds)}</span>
          </div>
        );
      })}
    </div>
  );
}
