import type { Track } from './data';

const RATE = 22050;
const SCALE = [0, 2, 4, 7, 9, 12, 14, 16];
const cache = new Map<string, string>();

function rng(seed: number) {
  let s = seed >>> 0 || 1;
  return () => ((s = (s * 1103515245 + 12345) >>> 0) / 2 ** 32);
}

/** Synthesizes a short, quiet arpeggio for a track and returns a WAV blob URL. */
export function toneUrl(t: Track): string {
  const hit = cache.get(t.id);
  if (hit) return hit;
  const { root, bpm, seed } = t.tone;
  const r = rng(seed);
  const n = Math.floor(t.seconds * RATE);
  const pcm = new Int16Array(n);
  const step = (60 / bpm / 2) * RATE;
  const pattern = Array.from({ length: 8 }, () => SCALE[Math.floor(r() * SCALE.length)]);
  const bass = [0, -5, -3, -7].map((x) => root * 2 ** ((x - 12) / 12));

  for (let i = 0; i < n; i++) {
    const noteIdx = Math.floor(i / step);
    const inNote = (i % step) / step;
    const freq = root * 2 ** (pattern[noteIdx % 8] / 12);
    const env = Math.min(1, inNote * 40) * Math.exp(-inNote * 3.2);
    const time = i / RATE;
    const lead = Math.sin(2 * Math.PI * freq * time) * 0.6 + Math.sin(4 * Math.PI * freq * time) * 0.15;
    const b = Math.sin(2 * Math.PI * bass[Math.floor(noteIdx / 8) % 4] * time) * 0.25;
    const fade = Math.min(1, time / 0.4, (t.seconds - time) / 0.8);
    pcm[i] = Math.max(-1, Math.min(1, (lead * env + b) * 0.35 * fade)) * 32767;
  }

  const buf = new ArrayBuffer(44 + pcm.byteLength);
  const v = new DataView(buf);
  const w = (o: number, s: string) => [...s].forEach((ch, k) => v.setUint8(o + k, ch.charCodeAt(0)));
  w(0, 'RIFF'); v.setUint32(4, 36 + pcm.byteLength, true); w(8, 'WAVE');
  w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  w(36, 'data'); v.setUint32(40, pcm.byteLength, true);
  new Int16Array(buf, 44).set(pcm);

  const url = URL.createObjectURL(new Blob([buf], { type: 'audio/wav' }));
  cache.set(t.id, url);
  return url;
}
