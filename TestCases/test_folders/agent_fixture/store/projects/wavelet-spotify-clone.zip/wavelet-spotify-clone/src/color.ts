import { useEffect, useState } from 'react';

export interface CoverColor {
  /** Most common saturated color in the image, as sampled. */
  raw: string;
  /** Same hue, darkened until white text passes WCAG AA (4.5:1). Used for backgrounds. */
  base: string;
}

const SAMPLE = 48;
const BUCKETS = 36;
const cache = new Map<string, CoverColor>();
const pending = new Map<string, Promise<CoverColor>>();

type RGB = [number, number, number];

function rgbToHsl([r, g, b]: RGB): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  const h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h * 60, s, l];
}

function hslToRgb(h: number, s: number, l: number): RGB {
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
  return [f(0) * 255, f(8) * 255, f(4) * 255];
}

const hex = (c: RGB) => '#' + c.map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');

function luminance([r, g, b]: RGB) {
  const lin = (v: number) => ((v /= 255) <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
  return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
}

export const contrastWithWhite = (c: RGB) => 1.05 / (luminance(c) + 0.05);

/** Picks the dominant color: pixels are grouped by hue and weighted by saturation, ignoring near-black and near-white. */
export function dominantColor(data: Uint8ClampedArray): RGB {
  const weight = new Float64Array(BUCKETS);
  const sums = Array.from({ length: BUCKETS }, () => [0, 0, 0]);
  const avg = [0, 0, 0];
  let count = 0;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] < 128) continue;
    const px: RGB = [data[i], data[i + 1], data[i + 2]];
    avg[0] += px[0]; avg[1] += px[1]; avg[2] += px[2]; count++;
    const [h, s, l] = rgbToHsl(px);
    if (l < 0.12 || l > 0.92 || s < 0.18) continue;
    const b = Math.floor(h / (360 / BUCKETS)) % BUCKETS;
    const w = s * (1 - Math.abs(l - 0.5));
    weight[b] += w;
    sums[b][0] += px[0] * w; sums[b][1] += px[1] * w; sums[b][2] += px[2] * w;
  }
  let best = -1;
  for (let b = 0; b < BUCKETS; b++) if (best < 0 || weight[b] > weight[best]) best = b;
  if (best < 0 || weight[best] === 0) return count ? (avg.map((v) => v / count) as RGB) : [40, 40, 40];
  return sums[best].map((v) => v / weight[best]) as RGB;
}

/** Darkens a color (keeping its hue) until white text on it clears WCAG AA 4.5:1, with a small margin for rounding. */
export function readableBackground(c: RGB, target = 4.7): RGB {
  let [h, s, l] = rgbToHsl(c);
  s = Math.min(s, 0.72);
  let out = hslToRgb(h, s, l);
  while (contrastWithWhite(out) < target && l > 0.04) {
    l -= 0.02;
    out = hslToRgb(h, s, l);
  }
  return out;
}

export function extractCoverColor(src: string): Promise<CoverColor> {
  const hit = cache.get(src);
  if (hit) return Promise.resolve(hit);
  const wait = pending.get(src);
  if (wait) return wait;
  const job = new Promise<CoverColor>((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = c.height = SAMPLE;
      const g = c.getContext('2d', { willReadFrequently: true })!;
      g.drawImage(img, 0, 0, SAMPLE, SAMPLE);
      const raw = dominantColor(g.getImageData(0, 0, SAMPLE, SAMPLE).data);
      const result = { raw: hex(raw), base: hex(readableBackground(raw)) };
      cache.set(src, result);
      pending.delete(src);
      resolve(result);
    };
    img.onerror = reject;
    img.src = src;
  });
  pending.set(src, job);
  return job;
}

/** Returns the cover's color, keeping the previous one until the new one is ready so the fade never flashes. */
export function useCoverColor(src: string | null, fallback = '#2a2830'): string {
  const [color, setColor] = useState(() => (src && cache.get(src)?.base) || fallback);
  useEffect(() => {
    if (!src) return setColor(fallback);
    let live = true;
    extractCoverColor(src).then((c) => live && setColor(c.base));
    return () => { live = false; };
  }, [src, fallback]);
  return color;
}
