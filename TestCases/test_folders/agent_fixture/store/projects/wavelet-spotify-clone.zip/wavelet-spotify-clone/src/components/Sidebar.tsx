import { Home as HomeIcon, Library, Search as SearchIcon, Volume2 } from 'lucide-react';
import { playlists } from '../data';
import { useCurrentTrack, usePlayer } from '../player';
import { href, type Route } from '../router';
import { Cover, Logo } from './common';

export function Sidebar({ route }: { route: Route }) {
  const { isPlaying } = usePlayer();
  const current = useCurrentTrack();
  return (
    <nav className="sidebar" aria-label="Main">
      <div className="panel nav-top">
        <div className="brand"><Logo /><span>Wavelet</span></div>
        <a className={`nav-link ${route.name === 'home' ? 'active' : ''}`} href={href({ name: 'home' })}><HomeIcon size={22} />Home</a>
        <a className={`nav-link ${route.name === 'search' ? 'active' : ''}`} href={href({ name: 'search', query: '' })}><SearchIcon size={22} />Search</a>
      </div>
      <div className="panel library">
        <div className="library-head"><Library size={22} />Your Library</div>
        <ul className="library-list">
          {playlists.map((p) => {
            const active = route.name === 'playlist' && route.id === p.id;
            const playingHere = current?.playlistId === p.id;
            return (
              <li key={p.id}>
                <a className={`library-item ${active ? 'active' : ''}`} href={href({ name: 'playlist', id: p.id })} data-testid={`library-${p.id}`}>
                  <Cover playlist={p} size={44} />
                  <span className="library-text">
                    <span className={`library-name ${playingHere ? 'playing' : ''}`}>{p.name}</span>
                    <span className="library-meta">Playlist · {p.trackIds.length} songs</span>
                  </span>
                  {playingHere && isPlaying && <Volume2 size={16} className="accent-icon" />}
                </a>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
