import { X } from 'lucide-react';
import type { CSSProperties } from 'react';
import { playlistById } from '../data';
import { coverUrl } from '../covers';
import { useCoverColor } from '../color';
import { player, useCurrentTrack, usePlayer } from '../player';
import { Cover } from './common';

export function NowPlaying({ onClose }: { onClose: () => void }) {
  usePlayer();
  const t = useCurrentTrack();
  const p = t ? playlistById.get(t.playlistId) : undefined;
  const color = useCoverColor(p ? coverUrl(p) : null, '#24232b');
  const next = player.upNext(4);
  return (
    <aside className="panel now-playing" aria-label="Now playing" data-testid="now-playing" style={{ '--page': color } as CSSProperties}>
      <div className="np-head">
        <span>{p ? p.name : 'Now playing'}</span>
        <button className="icon-btn" aria-label="Close panel" onClick={onClose}><X size={18} /></button>
      </div>
      {t && p ? (
        <>
          <Cover playlist={p} size={260} className="np-cover" />
          <div className="np-title">{t.title}</div>
          <div className="np-artist">{t.artist}</div>
          <div className="np-next">
            <div className="np-next-title">Next in queue</div>
            {next.length ? next.map((n) => (
              <button key={n.id} className="np-next-item" onClick={() => player.playContext(player.state.contextId ?? n.playlistId, n.id)}>
                <Cover playlist={playlistById.get(n.playlistId)!} size={40} />
                <span><span className="track-title">{n.title}</span><span className="track-artist">{n.artist}</span></span>
              </button>
            )) : <p className="empty small">End of the queue.</p>}
          </div>
        </>
      ) : (
        <p className="empty">Pick a playlist to start listening.</p>
      )}
    </aside>
  );
}
