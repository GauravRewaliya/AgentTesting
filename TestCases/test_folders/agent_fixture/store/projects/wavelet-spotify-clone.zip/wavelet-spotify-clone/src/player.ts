import { useSyncExternalStore } from 'react';
import { playlistById, trackById, type Track } from './data';
import { toneUrl } from './tones';

export type Repeat = 'off' | 'all' | 'one';

export interface PlayerState {
  contextId: string | null;
  queue: string[];
  order: number[];
  pos: number;
  isPlaying: boolean;
  position: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: Repeat;
}

const VOLUME_KEY = 'wavelet:volume';

function loadVolume() {
  try {
    const v = Number(localStorage.getItem(VOLUME_KEY));
    return Number.isFinite(v) && v > 0 && v <= 1 ? v : 0.7;
  } catch {
    return 0.7;
  }
}

function shuffled(n: number, first: number) {
  const rest = Array.from({ length: n }, (_, i) => i).filter((i) => i !== first);
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [rest[i], rest[j]] = [rest[j], rest[i]];
  }
  return [first, ...rest];
}

/** Same verbs as Spotify's PlayerAPI (skipToNext, seekTo, setVolume…), backed by one <audio> element. */
class PlayerAPI {
  private audio = new Audio();
  private listeners = new Set<() => void>();
  private raf = 0;
  state: PlayerState = {
    contextId: null, queue: [], order: [], pos: 0, isPlaying: false,
    position: 0, duration: 0, volume: loadVolume(), muted: false, shuffle: false, repeat: 'off',
  };

  constructor() {
    this.audio.preload = 'auto';
    this.audio.volume = this.state.volume;
    this.audio.addEventListener('ended', () => this.onEnded());
    this.audio.addEventListener('loadedmetadata', () => this.set({ duration: this.audio.duration }));
    this.audio.addEventListener('play', () => { this.set({ isPlaying: true }); this.tick(); });
    this.audio.addEventListener('pause', () => this.set({ isPlaying: false, position: this.audio.currentTime }));
  }

  subscribe = (fn: () => void) => { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; };
  getSnapshot = () => this.state;

  private set(patch: Partial<PlayerState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((fn) => fn());
  }

  private tick = () => {
    cancelAnimationFrame(this.raf);
    if (this.audio.paused) return;
    this.set({ position: this.audio.currentTime });
    this.raf = requestAnimationFrame(this.tick);
  };

  get current(): Track | null {
    const { queue, order, pos } = this.state;
    const id = queue[order[pos]];
    return id ? trackById.get(id) ?? null : null;
  }

  private load(autoplay: boolean) {
    const t = this.current;
    if (!t) return;
    this.audio.src = toneUrl(t);
    this.audio.currentTime = 0;
    this.set({ position: 0, duration: t.seconds });
    if (autoplay) void this.audio.play().catch(() => this.set({ isPlaying: false }));
  }

  playContext(contextId: string, trackId?: string) {
    const list = playlistById.get(contextId);
    if (!list) return;
    const start = Math.max(0, trackId ? list.trackIds.indexOf(trackId) : 0);
    const order = this.state.shuffle ? shuffled(list.trackIds.length, start) : list.trackIds.map((_, i) => i);
    this.set({ contextId, queue: list.trackIds, order, pos: order.indexOf(start) });
    this.load(true);
  }

  togglePlay() {
    if (!this.current) {
      const first = playlistById.keys().next().value;
      if (first) this.playContext(first);
      return;
    }
    if (this.audio.paused) void this.audio.play(); else this.audio.pause();
  }

  skipToNext() {
    const { pos, order, repeat } = this.state;
    if (pos + 1 < order.length) this.set({ pos: pos + 1 });
    else if (repeat !== 'off') this.set({ pos: 0 });
    else return;
    this.load(true);
  }

  skipToPrevious() {
    if (this.audio.currentTime > 3 || this.state.pos === 0) return this.seekTo(0);
    this.set({ pos: this.state.pos - 1 });
    this.load(true);
  }

  seekTo(seconds: number) {
    const d = this.audio.duration || this.state.duration;
    this.audio.currentTime = Math.max(0, Math.min(seconds, d));
    this.set({ position: this.audio.currentTime });
  }

  setVolume(v: number) {
    const volume = Math.max(0, Math.min(1, v));
    this.audio.volume = volume;
    this.audio.muted = false;
    try { if (volume > 0) localStorage.setItem(VOLUME_KEY, String(volume)); } catch { /* storage blocked */ }
    this.set({ volume, muted: false });
  }

  toggleMute() {
    this.audio.muted = !this.state.muted;
    this.set({ muted: !this.state.muted });
  }

  setShuffle(on: boolean) {
    const { queue, order, pos } = this.state;
    const cur = order[pos] ?? 0;
    const next = on ? shuffled(queue.length, cur) : queue.map((_, i) => i);
    this.set({ shuffle: on, order: next, pos: next.indexOf(cur) });
  }

  setRepeat(repeat: Repeat) { this.set({ repeat }); }

  cycleRepeat() {
    const next: Record<Repeat, Repeat> = { off: 'all', all: 'one', one: 'off' };
    this.setRepeat(next[this.state.repeat]);
  }

  private onEnded() {
    const { repeat, pos, order } = this.state;
    if (repeat === 'one') { this.seekTo(0); void this.audio.play(); return; }
    if (pos + 1 < order.length || repeat === 'all') return this.skipToNext();
    this.seekTo(0);
    this.set({ isPlaying: false });
  }

  upNext(count: number): Track[] {
    const { queue, order, pos } = this.state;
    return order.slice(pos + 1, pos + 1 + count).map((i) => trackById.get(queue[i])!).filter(Boolean);
  }
}

export const player = new PlayerAPI();

export function usePlayer() {
  return useSyncExternalStore(player.subscribe, player.getSnapshot);
}

export function useCurrentTrack(): Track | null {
  const s = usePlayer();
  const id = s.queue[s.order[s.pos]];
  return id ? trackById.get(id) ?? null : null;
}
