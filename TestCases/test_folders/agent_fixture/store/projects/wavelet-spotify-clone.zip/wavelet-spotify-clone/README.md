# Wavelet

A web rebuild of the Spotify desktop player's layout and behavior, made for learning.
Own name, logo, colors and fonts (Outfit + DM Mono). lucide-react icons. Covers are drawn in code, and audio is synthesized in code.
No Spotify logo, icons, fonts, cover art, audio or brand text.

```bash
npm install && npm run dev
```

Opens on http://localhost:5200.

## Is Spotify desktop CEF or Electron? CEF

Checked read-only on the installed app (v1.2.98.301) with REA.

| Evidence | Result |
|---|---|
| `Contents/Frameworks/Chromium Embedded Framework.framework` | present |
| Its `Info.plist` `CFBundleIdentifier` | `org.cef.framework`, version `146.0.10.0` |
| Strings in the CEF binary | `Chrome/146.0.7680.179` |
| `*.asar` or `*electron*` files in the bundle | `0` |
| `Contents/Resources/Apps/xpui.spa` | `Zip archive data` (the web UI) |
| REA on the unzipped UI | 0 Electron windows, 0 preload scripts, 0 IPC channels |

The UI is React 18.3.1.
The core modules ship inside CEF's `v8_context_snapshot.arm64.bin`, not in the `.spa`.

## How the background color is chosen

**Spotify: sent by the server.** No UI file calls `getImageData` (0 of 248 files).
The album page reads the color from a field in the server's response instead.

There are three shades per image (`colorRaw`, `colorDark`, `colorLight`) requested per album or playlist.
The hex goes into a CSS variable `--background-base`, and a gradient fades it into the page:
`linear-gradient(var(--background-base) 0%, var(--background-base-70) 40%)`.

**Wavelet: computed in the browser** (`src/color.ts`), since there is no server:

1. Load the cover into an `Image` and draw it onto a 48×48 canvas.
2. Read the pixels with `getImageData`.
3. Skip near-black, near-white and grey pixels. Group the rest into 36 hue buckets, weighted by saturation and mid-lightness.
4. The heaviest bucket's average color is the "raw" color, like Spotify's `colorRaw`.
5. Keep the hue and darken until white text reaches at least 4.7:1 contrast. That clears WCAG AA (4.5:1) with a margin. This becomes `--page`.
6. `--page` is registered with `@property { syntax: '<color>' }`, so the gradient itself animates. A `480ms ease` transition fades between playlists. Measured settle time is 452 ms.
7. Until a new color is ready, the hook keeps the old one, so the fade never flashes.

## What came from the analysis vs. my own design

| From the analysis | My own design |
|---|---|
| Layout: sidebar, main view, Now Playing panel, bottom player bar | Name, logo, violet accent, dark ink palette, fonts |
| Player verbs named like Spotify's `PlayerAPI`: `skipToNext`, `skipToPrevious`, `seekTo`, `setVolume`, `setShuffle`, `setRepeat` (`src/player.ts`) | One `<audio>` element plus `useSyncExternalStore` in place of the native engine |
| Color applied as a CSS variable, then a gradient into the page | Color extracted on device (Spotify gets it from the server) |
| Route patterns `/`, `/search/:query`, `/playlist/:id` | Hash routing, no router library |
| Player test IDs (`control-button-playpause`, `progress-bar`, `volume-bar`…) mirrored as `data-testid` | Generated covers (`src/covers.ts`) and synthesized WAV tones (`src/tones.ts`) |

## Data

8 playlists and 40 tracks with made-up names (`src/data.ts`).
Each track is a 16–30 s arpeggio rendered to WAV on first play.
Volume is remembered in `localStorage`.

## Controls

- Space: play/pause (ignored while typing)
- Player bar: play/pause, previous (restarts if more than 3 s in), next, shuffle, repeat (off → all → one), seek, volume and mute
- Sliders: click, drag, or use the arrow keys
- Track rows: double-click, or hover and press the play button

## Checks

The automated checks and the full analysis notes live in my project folder and aren't part of this download.

## Not built

Real accounts, streaming, lyrics, queue editing, likes, podcasts, Connect devices.
